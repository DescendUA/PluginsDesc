package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.UUID;

public class DocCommand implements CommandExecutor {

    private final DescRP plugin;

    public DocCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("descrp.doc.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
            return true;
        }

        if (args.length < 1) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("issue")) {
            // /doc issue <ник> <passport|license|permit> <имя> <фамилия>
            if (args.length < 5) {
                sender.sendMessage(ChatColor.RED + "Использование: /doc issue <ник> <passport|license|permit> <имя> <фамилия>");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                return true;
            }

            DocumentManager.DocType type = parseType(args[2]);
            if (type == null) {
                sender.sendMessage(ChatColor.RED + "Тип документа: passport, license, permit.");
                return true;
            }

            String firstName = args[3];
            String lastName = args[4];

            plugin.getDocumentManager().issueDocument(target.getUniqueId(), type, firstName, lastName);
            sender.sendMessage(ChatColor.GREEN + "Документ (" + type.name() + ") выдан игроку " + target.getName() + ".");
            target.sendMessage(ChatColor.GREEN + "Вам выдан документ: " + ChatColor.WHITE + typeLabel(type));
            return true;
        }

        if (sub.equals("revoke")) {
            // /doc revoke <ник> <passport|license|permit>
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Использование: /doc revoke <ник> <passport|license|permit>");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                return true;
            }

            DocumentManager.DocType type = parseType(args[2]);
            if (type == null) {
                sender.sendMessage(ChatColor.RED + "Тип документа: passport, license, permit.");
                return true;
            }

            plugin.getDocumentManager().revokeDocument(target.getUniqueId(), type);
            sender.sendMessage(ChatColor.GREEN + "Документ отозван у " + target.getName() + ".");
            return true;
        }

        sendUsage(sender);
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.GRAY + "/doc issue <ник> <passport|license|permit> <имя> <фамилия>");
        sender.sendMessage(ChatColor.GRAY + "/doc revoke <ник> <passport|license|permit>");
    }

    private DocumentManager.DocType parseType(String raw) {
        switch (raw.toLowerCase()) {
            case "passport": return DocumentManager.DocType.PASSPORT;
            case "license": return DocumentManager.DocType.DRIVER_LICENSE;
            case "permit": return DocumentManager.DocType.WORK_PERMIT;
            default: return null;
        }
    }

    private String typeLabel(DocumentManager.DocType type) {
        switch (type) {
            case PASSPORT: return "Паспорт";
            case DRIVER_LICENSE: return "Водительское удостоверение";
            case WORK_PERMIT: return "Разрешение на работу";
            default: return type.name();
        }
    }
}
