package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.UUID;

public class PhoneChatListener implements Listener {

    private final DescRP plugin;

    public PhoneChatListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        PhoneManager.PendingAction action = plugin.getPhoneManager().getPending(uuid);
        if (action == null) return;

        event.setCancelled(true);
        String message = event.getMessage().trim();

        plugin.getServer().getScheduler().runTask(plugin, () -> handlePendingInput(player, action, message));
    }

    private void handlePendingInput(Player player, PhoneManager.PendingAction action, String message) {
        PhoneManager manager = plugin.getPhoneManager();
        LanguageManager lang = plugin.getLanguageManager();
        UUID uuid = player.getUniqueId();

        switch (action.type) {
            case ADD_CONTACT_NUMBER: {
                if (message.equalsIgnoreCase("отмена") || message.equalsIgnoreCase("cancel")) {
                    manager.setPending(uuid, null);
                    player.sendMessage(ChatColor.GRAY + lang.get(uuid, "msg.cancelled"));
                    return;
                }

                if (!message.matches("\\d{6}")) {
                    player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.number-format-error"));
                    return;
                }

                UUID targetUUID = manager.getOwnerByNumber(message);
                if (targetUUID == null) {
                    player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.number-not-found"));
                    manager.setPending(uuid, null);
                    return;
                }

                if (targetUUID.equals(uuid)) {
                    player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.cannot-add-self"));
                    manager.setPending(uuid, null);
                    return;
                }

                PhoneManager.PendingAction next = new PhoneManager.PendingAction(PhoneManager.PendingType.ADD_CONTACT_NAME);
                next.tempNumber = message;
                manager.setPending(uuid, next);
                player.sendMessage(ChatColor.YELLOW + lang.get(uuid, "msg.enter-contact-name"));
                return;
            }

            case ADD_CONTACT_NAME: {
                manager.addContact(uuid, action.tempNumber, message);
                manager.setPending(uuid, null);
                player.sendMessage(ChatColor.GREEN + lang.get(uuid, "msg.contact-added") + " " + ChatColor.WHITE + message);
                return;
            }

            case SEND_MESSAGE: {
                manager.setPending(uuid, null);

                Player target = plugin.getServer().getPlayer(action.targetUUID);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.recipient-offline"));
                    return;
                }

                if (!manager.isNotificationsEnabled(action.targetUUID)) {
                    player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.recipient-notifications-off"));
                    return;
                }

                String senderNumber = manager.getOrCreateNumber(uuid);
                target.sendMessage(ChatColor.AQUA + "\u2709 SMS " + lang.get(action.targetUUID, "msg.from") + " " + senderNumber + ": " + ChatColor.WHITE + message);
                player.sendMessage(ChatColor.GREEN + "\u2709 " + lang.get(uuid, "msg.message-sent"));
                return;
            }
        }
    }
}
