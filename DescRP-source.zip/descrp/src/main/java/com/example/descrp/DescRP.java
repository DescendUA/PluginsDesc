package com.example.descrp;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class DescRP extends JavaPlugin {

    private static DescRP instance;
    private PhoneManager phoneManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.phoneManager = new PhoneManager(this);
        phoneManager.load();

        getServer().getPluginManager().registerEvents(new PhoneGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneInteractListener(this), this);

        PluginCommand cmd = getCommand("phone");
        if (cmd != null) {
            cmd.setExecutor(new PhoneCommand(this));
        }

        getLogger().info("DescRP включен! Телефоны сервера Descend готовы к работе.");
    }

    @Override
    public void onDisable() {
        if (phoneManager != null) {
            phoneManager.save();
        }
        getLogger().info("DescRP выключен, данные телефонов сохранены.");
    }

    public static DescRP getInstance() {
        return instance;
    }

    public PhoneManager getPhoneManager() {
        return phoneManager;
    }
}
