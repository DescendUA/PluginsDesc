package com.example.descrp;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class PhoneManager {

    private final DescRP plugin;
    private final File dataFile;

    // playerUUID -> phone number
    private final Map<UUID, String> numbers = new HashMap<>();
    // phone number -> playerUUID
    private final Map<String, UUID> numberOwners = new HashMap<>();
    // playerUUID -> (contactNumber -> contactName)
    private final Map<UUID, Map<String, String>> contacts = new HashMap<>();

    // in-memory pending chat actions (add contact / send message flow)
    private final Map<UUID, PendingAction> pending = new HashMap<>();

    private final Random random = new Random();

    public PhoneManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        numbers.clear();
        numberOwners.clear();
        contacts.clear();

        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection playersSection = yml.getConfigurationSection("players");
        if (playersSection == null) return;

        for (String uuidStr : playersSection.getKeys(false)) {
            UUID uuid;
            try {
                uuid = UUID.fromString(uuidStr);
            } catch (IllegalArgumentException ex) {
                continue;
            }

            String number = playersSection.getString(uuidStr + ".number");
            if (number != null) {
                numbers.put(uuid, number);
                numberOwners.put(number, uuid);
            }

            ConfigurationSection contactsSection = playersSection.getConfigurationSection(uuidStr + ".contacts");
            if (contactsSection != null) {
                Map<String, String> map = new LinkedHashMap<>();
                for (String contactNumber : contactsSection.getKeys(false)) {
                    map.put(contactNumber, contactsSection.getString(contactNumber));
                }
                contacts.put(uuid, map);
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();

        for (Map.Entry<UUID, String> entry : numbers.entrySet()) {
            String path = "players." + entry.getKey() + ".number";
            yml.set(path, entry.getValue());
        }

        for (Map.Entry<UUID, Map<String, String>> entry : contacts.entrySet()) {
            String base = "players." + entry.getKey() + ".contacts";
            for (Map.Entry<String, String> c : entry.getValue().entrySet()) {
                yml.set(base + "." + c.getKey(), c.getValue());
            }
        }

        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    public String getOrCreateNumber(UUID uuid) {
        String existing = numbers.get(uuid);
        if (existing != null) return existing;

        String generated;
        do {
            generated = generateNumber();
        } while (numberOwners.containsKey(generated));

        numbers.put(uuid, generated);
        numberOwners.put(generated, uuid);
        save();
        return generated;
    }

    private String generateNumber() {
        int value = 100000 + random.nextInt(900000);
        return String.valueOf(value);
    }

    public UUID getOwnerByNumber(String number) {
        return numberOwners.get(number);
    }

    public String getNumber(UUID uuid) {
        return numbers.get(uuid);
    }

    public Map<String, String> getContacts(UUID owner) {
        return contacts.computeIfAbsent(owner, k -> new LinkedHashMap<>());
    }

    public void addContact(UUID owner, String number, String name) {
        getContacts(owner).put(number, name);
        save();
    }

    public void removeContact(UUID owner, String number) {
        getContacts(owner).remove(number);
        save();
    }

    public PendingAction getPending(UUID uuid) {
        return pending.get(uuid);
    }

    public void setPending(UUID uuid, PendingAction action) {
        if (action == null) {
            pending.remove(uuid);
        } else {
            pending.put(uuid, action);
        }
    }

    public enum PendingType {
        ADD_CONTACT_NUMBER,
        ADD_CONTACT_NAME,
        SEND_MESSAGE
    }

    public static class PendingAction {
        public final PendingType type;
        public String tempNumber;
        public UUID targetUUID;

        public PendingAction(PendingType type) {
            this.type = type;
        }
    }
}
