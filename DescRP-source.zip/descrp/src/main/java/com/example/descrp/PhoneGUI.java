package com.example.descrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PhoneGUI {

    // ===== Holders — используются, чтобы отличать инвентари DescRP от чужих =====

    public static class MainHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class SettingsHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class ContactsHolder implements InventoryHolder {
        private final List<String> numbersInOrder;
        public ContactsHolder(List<String> numbersInOrder) { this.numbersInOrder = numbersInOrder; }
        public List<String> getNumbersInOrder() { return numbersInOrder; }
        @Override public Inventory getInventory() { return null; }
    }

    public static class DiaHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    // ===== Билд предметов =====

    public static ItemStack item(Material material, String name, String... lore) {
        return item(material, (short) 0, name, lore);
    }

    /** durability = 1 подключает кастомную текстуру из ресурспака (см. overrides в модели предмета) */
    public static ItemStack item(Material material, short durability, String name, String... lore) {
        ItemStack item = new ItemStack(material, 1, durability);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore.length > 0) {
            List<String> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(ChatColor.translateAlternateColorCodes('&', line));
            }
            meta.setLore(loreList);
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack glass() {
        ItemStack item = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short) 15);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(" ");
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack contactSkull(String ownerName, String displayName, String number) {
        ItemStack item = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwner(ownerName);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&b" + displayName));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Номер: " + ChatColor.WHITE + number);
        lore.add(ChatColor.YELLOW + "ЛКМ — написать сообщение");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    // ===== Главный экран (приложения) =====

    public static void openMain(DescRP plugin, Player player) {
        String title = plugin.getLanguageManager().get(player.getUniqueId(), "gui.main-title");
        Inventory inv = Bukkit.createInventory(new MainHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));

        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        inv.setItem(11, item(Material.REDSTONE_COMPARATOR, (short) 1,
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-settings"),
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-settings-lore")));

        inv.setItem(13, item(Material.PAPER, (short) 1,
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-sms"),
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-sms-lore")));

        inv.setItem(15, item(Material.BOOK,
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-dia"),
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-dia-lore")));

        player.openInventory(inv);
    }

    // ===== Настройки =====

    public static void openSettings(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.settings-title");
        Inventory inv = Bukkit.createInventory(new SettingsHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        String number = plugin.getPhoneManager().getOrCreateNumber(uuid);
        inv.setItem(10, item(Material.NAME_TAG,
                plugin.getLanguageManager().get(uuid, "gui.my-number"),
                "&f" + number));

        String currentLang = plugin.getPhoneManager().getLanguage(uuid);
        if (currentLang == null) currentLang = plugin.getLanguageManager().getDefaultLang();
        inv.setItem(12, item(Material.BOOK_AND_QUILL,
                plugin.getLanguageManager().get(uuid, "gui.language"),
                "&f" + currentLang.toUpperCase(),
                plugin.getLanguageManager().get(uuid, "gui.click-to-switch")));

        boolean notif = plugin.getPhoneManager().isNotificationsEnabled(uuid);
        inv.setItem(14, item(notif ? Material.EMERALD : Material.REDSTONE,
                plugin.getLanguageManager().get(uuid, "gui.notifications"),
                notif ? plugin.getLanguageManager().get(uuid, "gui.enabled")
                        : plugin.getLanguageManager().get(uuid, "gui.disabled"),
                plugin.getLanguageManager().get(uuid, "gui.click-to-toggle")));

        int contactsCount = plugin.getPhoneManager().getContacts(uuid).size();
        inv.setItem(16, item(Material.BOOKSHELF,
                plugin.getLanguageManager().get(uuid, "gui.contacts-count"),
                "&f" + contactsCount));

        inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== SMS / Контакты =====

    public static void openContacts(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        Map<String, String> contacts = plugin.getPhoneManager().getContacts(uuid);

        int itemRows = (int) Math.ceil(contacts.size() / 9.0);
        int rows = Math.max(2, itemRows + 1); // +1 ряд под кнопки "добавить"/"назад"
        int size = Math.min(54, rows * 9);

        List<String> order = new ArrayList<>(contacts.keySet());
        ContactsHolder holder = new ContactsHolder(order);
        String title = plugin.getLanguageManager().get(uuid, "gui.contacts-title");
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.translateAlternateColorCodes('&', title));

        int slot = 0;
        for (String number : order) {
            String name = contacts.get(number);
            inv.setItem(slot, contactSkull(name, name, number));
            slot++;
            if (slot >= size - 9) break;
        }

        inv.setItem(size - 9, item(Material.EMERALD,
                plugin.getLanguageManager().get(uuid, "gui.add-contact"),
                plugin.getLanguageManager().get(uuid, "gui.add-contact-lore")));
        inv.setItem(size - 1, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== Dia — документы =====

    public static void openDia(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        DocumentManager docs = plugin.getDocumentManager();
        String title = plugin.getLanguageManager().get(uuid, "gui.dia-title");
        Inventory inv = Bukkit.createInventory(new DiaHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        if (!docs.hasPassport(uuid)) {
            inv.setItem(13, item(Material.BARRIER,
                    plugin.getLanguageManager().get(uuid, "gui.no-passport"),
                    plugin.getLanguageManager().get(uuid, "gui.no-passport-lore")));
            inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));
            player.openInventory(inv);
            return;
        }

        DocumentManager.DocumentData passport = docs.getDocument(uuid, DocumentManager.DocType.PASSPORT);
        inv.setItem(4, item(Material.SKULL_ITEM, (short) 0,
                plugin.getLanguageManager().get(uuid, "gui.owner-info"),
                "&f" + passport.firstName + " " + passport.lastName,
                "&7ID: &f" + passport.id));

        inv.setItem(11, documentItem(plugin, uuid, DocumentManager.DocType.PASSPORT,
                plugin.getLanguageManager().get(uuid, "gui.doc-passport")));
        inv.setItem(13, documentItem(plugin, uuid, DocumentManager.DocType.DRIVER_LICENSE,
                plugin.getLanguageManager().get(uuid, "gui.doc-license")));
        inv.setItem(15, documentItem(plugin, uuid, DocumentManager.DocType.WORK_PERMIT,
                plugin.getLanguageManager().get(uuid, "gui.doc-permit")));

        inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    private static ItemStack documentItem(DescRP plugin, UUID uuid, DocumentManager.DocType type, String name) {
        DocumentManager.DocumentData data = plugin.getDocumentManager().getDocument(uuid, type);
        if (data == null) {
            return item(Material.PAPER, name,
                    plugin.getLanguageManager().get(uuid, "gui.doc-not-issued"));
        }
        return item(Material.WRITTEN_BOOK, name,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-owner") + ": &f" + data.firstName + " " + data.lastName,
                "&7ID: &f" + data.id,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-date") + ": &f" + data.issueDate);
    }
}
