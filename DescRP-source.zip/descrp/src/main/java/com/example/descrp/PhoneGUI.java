package com.example.descrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PhoneGUI {

    // ===== Holders — используются, чтобы отличать инвентари DescRP от чужих =====

    public static class MainHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class SettingsHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class ContactsHolder implements InventoryHolder {
        private final List<String> numbersInOrder;
        public ContactsHolder(List<String> numbersInOrder) { this.numbersInOrder = numbersInOrder; }
        public List<String> getNumbersInOrder() { return numbersInOrder; }
        @Override public Inventory getInventory() { return null; }
    }

    // ===== Билд предметов =====

    public static ItemStack item(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore.length > 0) {
            List<String> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(ChatColor.translateAlternateColorCodes('&', line));
            }
            meta.setLore(loreList);
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack glass() {
        ItemStack item = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short) 15);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(" ");
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack contactSkull(String ownerName, String displayName, String number) {
        ItemStack item = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwner(ownerName);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&b" + displayName));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Номер: " + ChatColor.WHITE + number);
        lore.add(ChatColor.YELLOW + "ЛКМ — написать сообщение");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    // ===== Экраны =====

    public static void openMain(DescRP plugin, Player player) {
        Inventory inv = Bukkit.createInventory(new MainHolder(), 9, ChatColor.translateAlternateColorCodes('&', "&8Телефон"));

        for (int i = 0; i < 9; i++) inv.setItem(i, glass());

        inv.setItem(3, item(Material.REDSTONE_COMPARATOR, "&7&lНастройки", "&fПосмотреть свой номер"));
        inv.setItem(5, item(Material.PAPER, "&e&lSMS", "&fКонтакты и сообщения"));

        player.openInventory(inv);
    }

    public static void openSettings(DescRP plugin, Player player) {
        Inventory inv = Bukkit.createInventory(new SettingsHolder(), 9, ChatColor.translateAlternateColorCodes('&', "&8Настройки"));
        for (int i = 0; i < 9; i++) inv.setItem(i, glass());

        String number = plugin.getPhoneManager().getOrCreateNumber(player.getUniqueId());
        inv.setItem(4, item(Material.NAME_TAG, "&aВаш номер", "&f" + number));
        inv.setItem(8, item(Material.BARRIER, "&cНазад"));

        player.openInventory(inv);
    }

    public static void openContacts(DescRP plugin, Player player) {
        Map<String, String> contacts = plugin.getPhoneManager().getContacts(player.getUniqueId());

        int itemRows = (int) Math.ceil(contacts.size() / 9.0);
        int rows = Math.max(2, itemRows + 1); // +1 ряд под кнопки "добавить"/"назад"
        int size = Math.min(54, rows * 9);

        List<String> order = new ArrayList<>(contacts.keySet());
        ContactsHolder holder = new ContactsHolder(order);
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.translateAlternateColorCodes('&', "&8SMS — Контакты"));

        int slot = 0;
        for (String number : order) {
            String name = contacts.get(number);
            inv.setItem(slot, contactSkull(name, name, number));
            slot++;
            if (slot >= size - 9) break;
        }

        inv.setItem(size - 9, item(Material.EMERALD, "&a&lДобавить контакт", "&fВвести номер друга"));
        inv.setItem(size - 1, item(Material.BARRIER, "&cНазад"));

        player.openInventory(inv);
    }
}
