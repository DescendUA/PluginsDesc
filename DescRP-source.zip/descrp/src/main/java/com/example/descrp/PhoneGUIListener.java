package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;
import java.util.UUID;

public class PhoneGUIListener implements Listener {

    private final DescRP plugin;

    public PhoneGUIListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        Object holder = event.getInventory().getHolder();

        if (holder instanceof PhoneGUI.MainHolder) {
            event.setCancelled(true);
            handleMainClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.SettingsHolder) {
            event.setCancelled(true);
            handleSettingsClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.ContactsHolder) {
            event.setCancelled(true);
            handleContactsClick(player, event.getRawSlot(), (PhoneGUI.ContactsHolder) holder, event.getCurrentItem());
            return;
        }

        if (holder instanceof PhoneGUI.DiaHolder) {
            event.setCancelled(true);
            handleDiaClick(player, event.getRawSlot());
        }
    }

    private void handleMainClick(Player player, int slot) {
        if (slot == 11) {
            PhoneGUI.openSettings(plugin, player);
        } else if (slot == 13) {
            PhoneGUI.openContacts(plugin, player);
        } else if (slot == 15) {
            PhoneGUI.openDia(plugin, player);
        }
    }

    private void handleSettingsClick(Player player, int slot) {
        UUID uuid = player.getUniqueId();

        if (slot == 12) {
            String newLang = plugin.getPhoneManager().cycleLanguage(uuid);
            player.sendMessage(ChatColor.GREEN + plugin.getLanguageManager().get(uuid, "msg.language-switched") + " " + newLang.toUpperCase());
            PhoneGUI.openSettings(plugin, player);
            return;
        }

        if (slot == 14) {
            plugin.getPhoneManager().toggleNotifications(uuid);
            PhoneGUI.openSettings(plugin, player);
            return;
        }

        if (slot == 26) {
            PhoneGUI.openMain(plugin, player);
        }
    }

    private void handleContactsClick(Player player, int slot, PhoneGUI.ContactsHolder holder, ItemStack clicked) {
        List<String> order = holder.getNumbersInOrder();
        int rows = Math.max(2, (int) Math.ceil(order.size() / 9.0) + 1);
        int size = Math.min(54, rows * 9);

        if (slot == size - 1) { // назад
            PhoneGUI.openMain(plugin, player);
            return;
        }

        if (slot == size - 9) { // добавить контакт
            player.closeInventory();
            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.ADD_CONTACT_NUMBER);
            plugin.getPhoneManager().setPending(player.getUniqueId(), action);
            player.sendMessage(ChatColor.YELLOW + plugin.getLanguageManager().get(player.getUniqueId(), "msg.enter-number-to-add"));
            return;
        }

        if (slot >= 0 && slot < order.size() && clicked != null && clicked.getItemMeta() instanceof SkullMeta) {
            String number = order.get(slot);
            UUID targetUUID = plugin.getPhoneManager().getOwnerByNumber(number);
            if (targetUUID == null) {
                player.sendMessage(ChatColor.RED + plugin.getLanguageManager().get(player.getUniqueId(), "msg.number-invalid"));
                return;
            }

            player.closeInventory();
            String contactName = plugin.getPhoneManager().getContacts(player.getUniqueId()).get(number);

            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.SEND_MESSAGE);
            action.targetUUID = targetUUID;
            plugin.getPhoneManager().setPending(player.getUniqueId(), action);

            player.sendMessage(ChatColor.YELLOW + plugin.getLanguageManager().get(player.getUniqueId(), "msg.enter-message-for") + " " + ChatColor.WHITE + contactName + ChatColor.YELLOW + ":");
        }
    }

    private void handleDiaClick(Player player, int slot) {
        if (slot == 26) {
            PhoneGUI.openMain(plugin, player);
        }
    }
}
