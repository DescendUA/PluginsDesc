package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;
import java.util.UUID;

public class PhoneGUIListener implements Listener {

    private final DescRP plugin;

    public PhoneGUIListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        Object holder = event.getInventory().getHolder();

        if (holder instanceof PhoneGUI.MainHolder) {
            event.setCancelled(true);
            handleMainClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.SettingsHolder) {
            event.setCancelled(true);
            handleSettingsClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.ContactsHolder) {
            event.setCancelled(true);
            handleContactsClick(player, event.getRawSlot(), (PhoneGUI.ContactsHolder) holder, event.getCurrentItem());
        }
    }

    private void handleMainClick(Player player, int slot) {
        if (slot == 3) {
            PhoneGUI.openSettings(plugin, player);
        } else if (slot == 5) {
            PhoneGUI.openContacts(plugin, player);
        }
    }

    private void handleSettingsClick(Player player, int slot) {
        if (slot == 8) {
            PhoneGUI.openMain(plugin, player);
        }
    }

    private void handleContactsClick(Player player, int slot, PhoneGUI.ContactsHolder holder, ItemStack clicked) {
        int size = holder.getNumbersInOrder().isEmpty() ? 18
                : Math.min(54, (Math.max(2, (int) Math.ceil(holder.getNumbersInOrder().size() / 9.0) + 1)) * 9);

        List<String> order = holder.getNumbersInOrder();

        if (slot == size - 1) { // назад
            PhoneGUI.openMain(plugin, player);
            return;
        }

        if (slot == size - 9) { // добавить контакт
            player.closeInventory();
            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.ADD_CONTACT_NUMBER);
            plugin.getPhoneManager().setPending(player.getUniqueId(), action);
            player.sendMessage(ChatColor.YELLOW + "Введите в чат номер телефона друга, которого хотите добавить:");
            return;
        }

        if (slot >= 0 && slot < order.size() && clicked != null && clicked.getItemMeta() instanceof SkullMeta) {
            String number = order.get(slot);
            UUID targetUUID = plugin.getPhoneManager().getOwnerByNumber(number);
            if (targetUUID == null) {
                player.sendMessage(ChatColor.RED + "Этот номер больше недействителен.");
                return;
            }

            player.closeInventory();
            String contactName = plugin.getPhoneManager().getContacts(player.getUniqueId()).get(number);

            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.SEND_MESSAGE);
            action.targetUUID = targetUUID;
            plugin.getPhoneManager().setPending(player.getUniqueId(), action);

            player.sendMessage(ChatColor.YELLOW + "Введите сообщение для " + ChatColor.WHITE + contactName + ChatColor.YELLOW + ":");
        }
    }
}
