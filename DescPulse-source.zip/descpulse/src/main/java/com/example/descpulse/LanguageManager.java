package com.example.descpulse;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class LanguageManager {

    private final DescPulse plugin;
    private final Map<String, YamlConfiguration> languages = new HashMap<>();
    private String defaultLang;

    public LanguageManager(DescPulse plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        languages.clear();
        defaultLang = plugin.getConfig().getString("language", "ru");
        String[] langs = {"en", "ru", "ua"};
        for (String lang : langs) {
            File file = new File(plugin.getDataFolder(), "lang/" + lang + ".yml");
            if (file.exists()) {
                languages.put(lang, YamlConfiguration.loadConfiguration(file));
            }
        }
    }

    public void reload() {
        load();
    }

    public String get(String key) {
        return get(defaultLang, key);
    }

    public String get(String lang, String key) {
        YamlConfiguration config = languages.getOrDefault(lang, languages.get(defaultLang));
        if (config == null) return "&cMissing language file: " + lang;
        String value = config.getString(key);
        if (value == null) return "&c[missing: " + key + "]";
        return value;
    }

    public boolean hasLanguage(String lang) {
        return languages.containsKey(lang);
    }

    public String getDefaultLang() {
        return defaultLang;
    }

    public void setDefaultLang(String lang) {
        this.defaultLang = lang;
        plugin.getConfig().set("language", lang);
        plugin.saveConfig();
    }
}
