package com.example.descpulse;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DescCommand implements CommandExecutor, TabCompleter {

    private final DescPulse plugin;
    private final List<String> subCommands = Arrays.asList(
            "info", "reload", "help", "lang", "setjoin", "setquit", "toggle", "prize"
    );

    public DescCommand(DescPulse plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MessageManager mm = plugin.getMessageManager();

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "info":
                sendInfo(sender);
                return true;

            case "reload":
                if (!sender.hasPermission("descpulse.admin")) {
                    mm.send(sender, plugin.getLanguageManager().get("no-permission"));
                    return true;
                }
                plugin.reload();
                mm.send(sender, plugin.getLanguageManager().get("reload-success"));
                return true;

            case "help":
                sendHelp(sender);
                return true;

            case "lang": {
                if (!sender.hasPermission("descpulse.admin")) {
                    mm.send(sender, plugin.getLanguageManager().get("no-permission"));
                    return true;
                }
                if (args.length < 2) {
                    mm.send(sender, "&cИспользование: /descpulse lang <en|ru|ua>");
                    return true;
                }
                String lang = args[1].toLowerCase();
                if (!plugin.getLanguageManager().hasLanguage(lang)) {
                    mm.send(sender, "&cДоступные языки: en, ru, ua");
                    return true;
                }
                plugin.getLanguageManager().setDefaultLang(lang);
                mm.send(sender, "&aЯзык плагина изменён на: &f" + lang);
                return true;
            }

            case "setjoin": {
                if (!sender.hasPermission("descpulse.admin")) {
                    mm.send(sender, plugin.getLanguageManager().get("no-permission"));
                    return true;
                }
                if (args.length < 3) {
                    mm.send(sender, "&cИспользование: /descpulse setjoin <ник> <сообщение>");
                    return true;
                }
                String targetJoin = args[1];
                String messageJoin = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                plugin.getConfig().set("join-message.custom." + targetJoin, messageJoin);
                plugin.saveConfig();
                mm.send(sender, "&aПерсональное приветствие для &f" + targetJoin + "&a установлено.");
                return true;
            }

            case "setquit": {
                if (!sender.hasPermission("descpulse.admin")) {
                    mm.send(sender, plugin.getLanguageManager().get("no-permission"));
                    return true;
                }
                if (args.length < 3) {
                    mm.send(sender, "&cИспользование: /descpulse setquit <ник> <сообщение>");
                    return true;
                }
                String targetQuit = args[1];
                String messageQuit = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                plugin.getConfig().set("quit-message.custom." + targetQuit, messageQuit);
                plugin.saveConfig();
                mm.send(sender, "&aПерсональное прощание для &f" + targetQuit + "&a установлено.");
                return true;
            }

            case "toggle": {
                if (!sender.hasPermission("descpulse.admin")) {
                    mm.send(sender, plugin.getLanguageManager().get("no-permission"));
                    return true;
                }
                if (args.length < 2) {
                    mm.send(sender, "&cИспользование: /descpulse toggle <join|quit|automsg>");
                    return true;
                }
                String what = args[1].toLowerCase();
                String path = what.equals("join") ? "join-message.enabled"
                        : what.equals("quit") ? "quit-message.enabled"
                        : what.equals("automsg") ? "auto-messages.enabled" : null;
                if (path == null) {
                    mm.send(sender, "&cДоступно: join, quit, automsg");
                    return true;
                }
                boolean current = plugin.getConfig().getBoolean(path, true);
                plugin.getConfig().set(path, !current);
                plugin.saveConfig();
                if (what.equals("automsg")) {
                    plugin.stopAutoMessages();
                    if (!current) plugin.startAutoMessages();
                }
                mm.send(sender, "&f" + what + " &7теперь: " + (!current ? "&aвкл" : "&cвыкл"));
                return true;
            }

            case "prize": {
                if (!sender.hasPermission("descpulse.admin")) {
                    mm.send(sender, plugin.getLanguageManager().get("no-permission"));
                    return true;
                }
                if (args.length < 2) {
                    mm.send(sender, "&cИспользование: /descpulse prize <ник> [название приза]");
                    return true;
                }

                String targetName = args[1];
                String prizeName = args.length >= 3 ? args[2] : "default";

                ConfigurationSection prizes = plugin.getConfig().getConfigurationSection("prizes");
                if (prizes == null || !prizes.contains(prizeName)) {
                    mm.send(sender, "&cПриз \"" + prizeName + "\" не найден в config.yml (раздел prizes).");
                    return true;
                }

                String cmdTemplate = prizes.getString(prizeName + ".command");
                if (cmdTemplate == null || cmdTemplate.trim().isEmpty()) {
                    mm.send(sender, "&cДля приза \"" + prizeName + "\" не задана команда (prizes." + prizeName + ".command).");
                    return true;
                }

                String finalCommand = cmdTemplate.replace("{player}", targetName);
                boolean success = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCommand);

                if (success) {
                    mm.send(sender, "&aПриз \"" + prizeName + "\" выдан игроку &f" + targetName + "&a.");
                } else {
                    mm.send(sender, "&cКоманда приза не выполнилась. Проверьте синтаксис в config.yml.");
                }
                return true;
            }

            default:
                sendHelp(sender);
                return true;
        }
    }

    private void sendInfo(CommandSender sender) {
        MessageManager mm = plugin.getMessageManager();
        sender.sendMessage(mm.color("&8&m----------------------------------------"));
        sender.sendMessage(mm.color("&b&lDescPulse &7» &fИнформационный плагин сервера Descend"));
        sender.sendMessage(mm.color("&7Версия: &f" + plugin.getDescription().getVersion()));
        sender.sendMessage(mm.color("&7Автор: &f" + String.join(", ", plugin.getDescription().getAuthors())));
        sender.sendMessage(mm.color("&7Язык: &f" + plugin.getLanguageManager().getDefaultLang()));
        sender.sendMessage(mm.color("&7Онлайн: &f" + plugin.getServer().getOnlinePlayers().size()));
        sender.sendMessage(mm.color("&8&m----------------------------------------"));
    }

    private void sendHelp(CommandSender sender) {
        MessageManager mm = plugin.getMessageManager();
        sender.sendMessage(mm.color("&8&m----------------------------------------"));
        sender.sendMessage(mm.color("&b&lDescPulse &7» &fСписок команд"));
        sender.sendMessage(mm.color("&f/descpulse info &7— информация о плагине"));
        sender.sendMessage(mm.color("&f/descpulse reload &7— перезагрузить конфиги"));
        sender.sendMessage(mm.color("&f/descpulse lang <en|ru|ua> &7— сменить язык"));
        sender.sendMessage(mm.color("&f/descpulse setjoin <ник> <текст> &7— своё приветствие"));
        sender.sendMessage(mm.color("&f/descpulse setquit <ник> <текст> &7— своё прощание"));
        sender.sendMessage(mm.color("&f/descpulse toggle <join|quit|automsg> &7— вкл/выкл"));
        sender.sendMessage(mm.color("&f/descpulse prize <ник> [название] &7— выдать приз"));
        sender.sendMessage(mm.color("&8&m----------------------------------------"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String s : subCommands) {
                if (s.startsWith(args[0].toLowerCase())) result.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("lang")) {
            for (String l : Arrays.asList("en", "ru", "ua")) {
                if (l.startsWith(args[1].toLowerCase())) result.add(l);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("toggle")) {
            for (String t : Arrays.asList("join", "quit", "automsg")) {
                if (t.startsWith(args[1].toLowerCase())) result.add(t);
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("prize")) {
            org.bukkit.configuration.ConfigurationSection prizes = plugin.getConfig().getConfigurationSection("prizes");
            if (prizes != null) {
                for (String key : prizes.getKeys(false)) {
                    if (key.startsWith(args[2].toLowerCase())) result.add(key);
                }
            }
        }
        return result;
    }
}
