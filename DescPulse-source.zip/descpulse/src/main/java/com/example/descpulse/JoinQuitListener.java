package com.example.descpulse;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class JoinQuitListener implements Listener {

    private final DescPulse plugin;

    public JoinQuitListener(DescPulse plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        MessageManager mm = plugin.getMessageManager();

        if (plugin.getConfig().getBoolean("join-message.enabled", true)) {
            String msg = plugin.getConfig().getString("join-message.custom." + player.getName(),
                    plugin.getLanguageManager().get("join-message"));
            msg = mm.placeholder(msg, "player", player.getName());
            msg = mm.placeholder(msg, "online", String.valueOf(plugin.getServer().getOnlinePlayers().size()));
            event.setJoinMessage(mm.color(msg));
        } else {
            event.setJoinMessage(null);
        }

        if (plugin.getConfig().getBoolean("first-join.enabled", true) && !player.hasPlayedBefore()) {
            String msg = plugin.getLanguageManager().get("first-join-message");
            msg = mm.placeholder(msg, "player", player.getName());
            plugin.getServer().broadcastMessage(mm.color(msg));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        MessageManager mm = plugin.getMessageManager();

        if (plugin.getConfig().getBoolean("quit-message.enabled", true)) {
            String msg = plugin.getConfig().getString("quit-message.custom." + player.getName(),
                    plugin.getLanguageManager().get("quit-message"));
            msg = mm.placeholder(msg, "player", player.getName());
            int online = Math.max(0, plugin.getServer().getOnlinePlayers().size() - 1);
            msg = mm.placeholder(msg, "online", String.valueOf(online));
            event.setQuitMessage(mm.color(msg));
        } else {
            event.setQuitMessage(null);
        }
    }
}
