package com.example.descpulse;

import org.bukkit.Bukkit;

import java.util.List;

public class AutoMessageTask implements Runnable {

    private final DescPulse plugin;
    private int index = 0;

    public AutoMessageTask(DescPulse plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        List<String> messages = plugin.getConfig().getStringList("auto-messages.messages");
        if (messages.isEmpty()) return;

        if (index >= messages.size()) index = 0;
        String raw = messages.get(index);
        index++;

        MessageManager mm = plugin.getMessageManager();
        boolean usePrefix = plugin.getConfig().getBoolean("auto-messages.use-prefix", true);

        for (String line : raw.split("\\\\n")) {
            String out = (usePrefix ? mm.prefix() : "") + mm.color(line);
            Bukkit.broadcastMessage(out);
        }
    }
}
