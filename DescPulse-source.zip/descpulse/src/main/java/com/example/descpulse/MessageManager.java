package com.example.descpulse;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class MessageManager {

    private final DescPulse plugin;

    public MessageManager(DescPulse plugin) {
        this.plugin = plugin;
    }

    public String color(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public String prefix() {
        return color(plugin.getConfig().getString("prefix", "&8[&bDescend&8] &r"));
    }

    public void send(CommandSender sender, String message) {
        sender.sendMessage(prefix() + color(message));
    }

    public void sendRaw(CommandSender sender, String message) {
        sender.sendMessage(color(message));
    }

    public String placeholder(String text, String key, String value) {
        return text.replace("{" + key + "}", value);
    }
}
