package com.example.descpulse;

import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.logging.Logger;

public class DescPulse extends JavaPlugin {

    private static DescPulse instance;
    private LanguageManager languageManager;
    private MessageManager messageManager;
    private int autoMessageTaskId = -1;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        saveDefaultLangFiles();

        this.languageManager = new LanguageManager(this);
        this.messageManager = new MessageManager(this);

        getServer().getPluginManager().registerEvents(new JoinQuitListener(this), this);

        PluginCommand cmd = getCommand("descpulse");
        if (cmd != null) {
            DescCommand executor = new DescCommand(this);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        startAutoMessages();
        printBanner();
        getLogger().info("DescPulse успешно запущен для сервера Descend!");
    }

    @Override
    public void onDisable() {
        stopAutoMessages();
        getLogger().info("DescPulse выключен. До встречи!");
    }

    public void reload() {
        reloadConfig();
        languageManager.reload();
        stopAutoMessages();
        startAutoMessages();
    }

    public void startAutoMessages() {
        if (!getConfig().getBoolean("auto-messages.enabled", true)) return;
        int interval = getConfig().getInt("auto-messages.interval-seconds", 300) * 20;
        AutoMessageTask task = new AutoMessageTask(this);
        autoMessageTaskId = getServer().getScheduler().scheduleSyncRepeatingTask(this, task, interval, interval);
    }

    public void stopAutoMessages() {
        if (autoMessageTaskId != -1) {
            getServer().getScheduler().cancelTask(autoMessageTaskId);
            autoMessageTaskId = -1;
        }
    }

    private void saveDefaultLangFiles() {
        String[] langs = {"en.yml", "ru.yml", "ua.yml"};
        for (String lang : langs) {
            File file = new File(getDataFolder(), "lang/" + lang);
            if (!file.exists()) {
                saveResource("lang/" + lang, false);
            }
        }
    }

    private void printBanner() {
        Logger log = getLogger();
        log.info(ChatColor.stripColor("========================================"));
        log.info(ChatColor.stripColor(" DescPulse v" + getDescription().getVersion() + " | Descend"));
        log.info(ChatColor.stripColor(" Автор: " + String.join(", ", getDescription().getAuthors())));
        log.info(ChatColor.stripColor("========================================"));
    }

    public static DescPulse getInstance() {
        return instance;
    }

    public LanguageManager getLanguageManager() {
        return languageManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }
}
