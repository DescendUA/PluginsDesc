package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class ChargingStationListener implements Listener {

    private final DescRP plugin;

    public ChargingStationListener(DescRP plugin) {
        this.plugin = plugin;
    }

    private Material stationMaterial() {
        String name = plugin.getConfig().getString("charging-station.material", "BONE_BLOCK");
        try {
            return Material.valueOf(name);
        } catch (IllegalArgumentException ex) {
            return Material.BONE_BLOCK;
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        // ВАЖНО: PlayerInteractEvent может сработать дважды на один клик (основная + запасная рука).
        // Обрабатываем только основную руку, иначе телефон мгновенно ставится и тут же забирается обратно.
        if (event.getHand() != EquipmentSlot.HAND) return;

        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != stationMaterial()) return;

        // Обычный (незарегистрированный) блок этого материала — никакой особой функции, ведёт себя как ванильный блок.
        if (!plugin.getChargingManager().isStation(event.getClickedBlock().getLocation())) return;

        event.setCancelled(true);

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        ChargingManager charging = plugin.getChargingManager();
        LanguageManager lang = plugin.getLanguageManager();

        ItemStack inHand = player.getInventory().getItemInMainHand();
        UUID dockedHere = charging.getDockedPlayer(event.getClickedBlock().getLocation());

        // Игрок держит телефон в руке -> пытается поставить на зарядку
        if (PhoneItems.isPhone(plugin, inHand)) {
            if (dockedHere != null) {
                if (dockedHere.equals(uuid)) {
                    player.sendMessage(ChatColor.YELLOW + lang.get(uuid, "msg.charger-already-yours"));
                } else {
                    player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.charger-occupied"));
                }
                return;
            }

            if (charging.isPlayerDocked(uuid)) {
                player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.already-charging-elsewhere"));
                return;
            }

            inHand.setAmount(inHand.getAmount() - 1);
            charging.dock(event.getClickedBlock().getLocation(), uuid);
            player.sendMessage(ChatColor.GREEN + lang.get(uuid, "msg.phone-docked"));
            return;
        }

        // Иначе — пытается забрать телефон со станции
        if (dockedHere == null) {
            player.sendMessage(ChatColor.GRAY + lang.get(uuid, "msg.charger-empty"));
            return;
        }

        if (!dockedHere.equals(uuid)) {
            player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.charger-not-yours"));
            return;
        }

        charging.undock(uuid);
        charging.updateLabel(event.getClickedBlock().getLocation());
        player.getInventory().addItem(PhoneItems.createPhoneItem(plugin));
        int battery = plugin.getPhoneManager().getBattery(uuid);
        player.sendMessage(ChatColor.GREEN + lang.get(uuid, "msg.phone-retrieved") + " (" + battery + "%)");
    }
}
