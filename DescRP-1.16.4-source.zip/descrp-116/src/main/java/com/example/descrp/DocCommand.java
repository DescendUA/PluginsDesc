package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DocCommand implements CommandExecutor {

    private final DescRP plugin;

    public DocCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        // /doc pending — игрок сам открывает заявку, ожидающую подтверждения. Прав админа не требует.
        if (sub.equals("pending")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
                return true;
            }
            Player player = (Player) sender;
            DocumentManager.DocRequest request = plugin.getDocumentManager().getRequest(player.getUniqueId());
            if (request == null) {
                player.sendMessage(ChatColor.GRAY + "У вас нет ожидающих заявок на документы.");
                return true;
            }
            PhoneGUI.openDocConfirm(plugin, player, request.type, request.firstName, request.lastName, request.issuerName);
            return true;
        }

        if (!sender.hasPermission("descrp.doc.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
            return true;
        }

        if (sub.equals("request")) {
            // /doc request <ник> passport <имя> <фамилия>   (заявка на паспорт, имя предлагает админ)
            // /doc request <ник> license|permit|medcard      (имя/фамилия берутся из паспорта игрока)
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Использование: /doc request <ник> <passport|license|permit|medcard> [имя] [фамилия]");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                return true;
            }

            DocumentManager.DocType type = parseType(args[2]);
            if (type == null) {
                sender.sendMessage(ChatColor.RED + "Тип документа: passport, license, permit, medcard.");
                return true;
            }

            String firstName;
            String lastName;

            if (type == DocumentManager.DocType.PASSPORT) {
                if (args.length < 5) {
                    sender.sendMessage(ChatColor.RED + "Использование: /doc request <ник> passport <имя> <фамилия>");
                    return true;
                }
                firstName = args[3];
                lastName = args[4];
            } else {
                DocumentManager.DocumentData passport = plugin.getDocumentManager().getDocument(target.getUniqueId(), DocumentManager.DocType.PASSPORT);
                if (passport == null) {
                    sender.sendMessage(ChatColor.RED + "У игрока " + target.getName() + " нет паспорта. Сначала он должен оформить его через Dia в телефоне.");
                    return true;
                }
                firstName = passport.firstName;
                lastName = passport.lastName;
            }

            String issuerName = sender instanceof Player ? sender.getName() : "Консоль";
            plugin.getDocumentManager().createRequest(target.getUniqueId(), type, firstName, lastName, issuerName);
            sender.sendMessage(ChatColor.GREEN + "Заявка на документ отправлена игроку " + target.getName() + ". Ожидаем подтверждения.");

            PhoneGUI.openDocConfirm(plugin, target, type, firstName, lastName, issuerName);
            target.sendMessage(ChatColor.YELLOW + "Вам предложили оформить документ: " + ChatColor.WHITE + PhoneGUI.docTypeLabel(plugin, target.getUniqueId(), type));
            return true;
        }

        if (sub.equals("issue")) {
            // /doc issue <ник> <passport|license|permit|medcard> [имя] [фамилия] — мгновенная выдача, без подтверждения
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Использование: /doc issue <ник> <passport|license|permit|medcard> [имя] [фамилия]");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                return true;
            }

            DocumentManager.DocType type = parseType(args[2]);
            if (type == null) {
                sender.sendMessage(ChatColor.RED + "Тип документа: passport, license, permit, medcard.");
                return true;
            }

            String firstName;
            String lastName;

            if (type == DocumentManager.DocType.PASSPORT) {
                if (args.length < 5) {
                    sender.sendMessage(ChatColor.RED + "Использование: /doc issue <ник> passport <имя> <фамилия>");
                    return true;
                }
                firstName = args[3];
                lastName = args[4];
            } else {
                DocumentManager.DocumentData passport = plugin.getDocumentManager().getDocument(target.getUniqueId(), DocumentManager.DocType.PASSPORT);
                if (passport == null) {
                    sender.sendMessage(ChatColor.RED + "У игрока " + target.getName() + " нет паспорта.");
                    return true;
                }
                firstName = passport.firstName;
                lastName = passport.lastName;
            }

            plugin.getDocumentManager().issueDocument(target.getUniqueId(), type, firstName, lastName);
            sender.sendMessage(ChatColor.GREEN + "Документ (" + type.name() + ") выдан игроку " + target.getName() + ".");
            target.sendMessage(ChatColor.GREEN + "Вам выдан документ: " + ChatColor.WHITE + PhoneGUI.docTypeLabel(plugin, target.getUniqueId(), type));
            return true;
        }

        if (sub.equals("revoke")) {
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Использование: /doc revoke <ник> <passport|license|permit|medcard>");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                return true;
            }

            DocumentManager.DocType type = parseType(args[2]);
            if (type == null) {
                sender.sendMessage(ChatColor.RED + "Тип документа: passport, license, permit, medcard.");
                return true;
            }

            plugin.getDocumentManager().revokeDocument(target.getUniqueId(), type);
            sender.sendMessage(ChatColor.GREEN + "Документ отозван у " + target.getName() + ".");
            return true;
        }

        if (sub.equals("setage")) {
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Использование: /doc setage <ник> <возраст>");
                return true;
            }

            Player target = plugin.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Игрок не найден или не в сети.");
                return true;
            }

            int newAge;
            try {
                newAge = Integer.parseInt(args[2]);
            } catch (NumberFormatException ex) {
                sender.sendMessage(ChatColor.RED + "Возраст должен быть числом.");
                return true;
            }

            if (newAge < 0 || newAge > 200) {
                sender.sendMessage(ChatColor.RED + "Возраст должен быть от 0 до 200.");
                return true;
            }

            plugin.getPhoneManager().setAge(target.getUniqueId(), newAge);
            sender.sendMessage(ChatColor.GREEN + "Возраст " + target.getName() + " установлен: " + newAge + ".");
            return true;
        }

        sendUsage(sender);
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ChatColor.GRAY + "/doc request <ник> <passport|license|permit|medcard> [имя] [фамилия] — с подтверждением");
        sender.sendMessage(ChatColor.GRAY + "/doc issue <ник> <passport|license|permit|medcard> [имя] [фамилия] — мгновенно");
        sender.sendMessage(ChatColor.GRAY + "/doc revoke <ник> <тип>");
        sender.sendMessage(ChatColor.GRAY + "/doc setage <ник> <возраст>");
        sender.sendMessage(ChatColor.GRAY + "/doc pending — открыть свою ожидающую заявку");
    }

    private DocumentManager.DocType parseType(String raw) {
        switch (raw.toLowerCase()) {
            case "passport": return DocumentManager.DocType.PASSPORT;
            case "license": return DocumentManager.DocType.DRIVER_LICENSE;
            case "permit": return DocumentManager.DocType.WORK_PERMIT;
            case "medcard": return DocumentManager.DocType.MEDICAL_CARD;
            default: return null;
        }
    }
}
