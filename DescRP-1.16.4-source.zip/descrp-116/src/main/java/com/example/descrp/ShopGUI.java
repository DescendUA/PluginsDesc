package com.example.descrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ShopGUI {

    public static class PhoneShopHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class TabacosShopHolder implements InventoryHolder {
        private final List<String> keysInOrder;
        public TabacosShopHolder(List<String> keysInOrder) { this.keysInOrder = keysInOrder; }
        public List<String> getKeysInOrder() { return keysInOrder; }
        @Override public Inventory getInventory() { return null; }
    }

    // ===== Магазин телефонов =====

    public static void openPhoneShop(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "shop.phones-title");
        Inventory inv = Bukkit.createInventory(new PhoneShopHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, PhoneGUI.glass());

        double price = plugin.getConfig().getDouble("shop.phones.regular-phone.price", 5000);
        inv.setItem(11, PhoneGUI.item(Material.IRON_INGOT, 1,
                plugin.getLanguageManager().get(uuid, "shop.regular-phone-name"),
                "&7" + plugin.getLanguageManager().get(uuid, "shop.price") + ": &f" + plugin.getEconomyManager().format(price),
                plugin.getLanguageManager().get(uuid, "shop.click-to-buy")));

        inv.setItem(15, PhoneGUI.item(Material.BARRIER,
                plugin.getLanguageManager().get(uuid, "shop.iphone-name"),
                "&7" + plugin.getLanguageManager().get(uuid, "shop.coming-soon")));

        inv.setItem(26, PhoneGUI.item(Material.OAK_DOOR, plugin.getLanguageManager().get(uuid, "shop.exit")));

        player.openInventory(inv);
    }

    // ===== Tabacos =====

    public static void openTabacosShop(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        ConfigurationSection items = plugin.getConfig().getConfigurationSection("shop.tabacos.items");
        List<String> keys = new ArrayList<>();
        if (items != null) keys.addAll(items.getKeys(false));

        String title = plugin.getLanguageManager().get(uuid, "shop.tabacos-title");
        Inventory inv = Bukkit.createInventory(new TabacosShopHolder(keys), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, PhoneGUI.glass());

        for (int i = 0; i < keys.size() && i < 7; i++) {
            String key = keys.get(i);
            inv.setItem(10 + i, buildTabacosItem(plugin, uuid, items, key));
        }

        inv.setItem(26, PhoneGUI.item(Material.OAK_DOOR, plugin.getLanguageManager().get(uuid, "shop.exit")));

        player.openInventory(inv);
    }

    private static ItemStack buildTabacosItem(DescRP plugin, UUID uuid, ConfigurationSection items, String key) {
        String name = items.getString(key + ".name", key);
        double price = items.getDouble(key + ".price", 0);
        String description = items.getString(key + ".description", "");
        String materialName = items.getString(key + ".material", "POTION");

        Material material;
        try {
            material = Material.valueOf(materialName);
        } catch (IllegalArgumentException ex) {
            material = Material.POTION;
        }

        return PhoneGUI.item(material, name,
                description,
                "&7" + plugin.getLanguageManager().get(uuid, "shop.price") + ": &f" + plugin.getEconomyManager().format(price),
                plugin.getLanguageManager().get(uuid, "shop.click-to-buy"));
    }
}
