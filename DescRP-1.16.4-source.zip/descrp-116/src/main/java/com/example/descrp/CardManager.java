package com.example.descrp;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class CardManager {

    public static class CardData {
        public String number;
        public String issueDate;
    }

    private final DescRP plugin;
    private final File dataFile;
    private final Map<UUID, CardData> debitCards = new HashMap<>();
    private final Random random = new Random();

    public CardManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "cards.yml");
    }

    public void load() {
        debitCards.clear();
        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        if (yml.getConfigurationSection("debit") == null) return;

        for (String uuidStr : yml.getConfigurationSection("debit").getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidStr);
                CardData data = new CardData();
                data.number = yml.getString("debit." + uuidStr + ".number");
                data.issueDate = yml.getString("debit." + uuidStr + ".issueDate");
                debitCards.put(uuid, data);
            } catch (Exception ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, CardData> entry : debitCards.entrySet()) {
            String base = "debit." + entry.getKey();
            yml.set(base + ".number", entry.getValue().number);
            yml.set(base + ".issueDate", entry.getValue().issueDate);
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить cards.yml: " + e.getMessage());
        }
    }

    public boolean hasDebitCard(UUID uuid) {
        return debitCards.containsKey(uuid);
    }

    public CardData getDebitCard(UUID uuid) {
        return debitCards.get(uuid);
    }

    public CardData issueDebitCard(UUID uuid) {
        CardData data = new CardData();
        data.number = generateCardNumber();
        data.issueDate = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
        debitCards.put(uuid, data);
        save();
        return data;
    }

    private String generateCardNumber() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            if (i > 0) sb.append(" ");
            sb.append(String.format("%04d", random.nextInt(10000)));
        }
        return sb.toString();
    }
}
