package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.potion.PotionEffect;

import java.util.List;
import java.util.UUID;

public class ShopListener implements Listener {

    private final DescRP plugin;

    public ShopListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        Object holder = event.getInventory().getHolder();

        if (holder instanceof ShopGUI.PhoneShopHolder) {
            event.setCancelled(true);
            handlePhoneShopClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof ShopGUI.TabacosShopHolder) {
            event.setCancelled(true);
            handleTabacosClick(player, event.getRawSlot(), (ShopGUI.TabacosShopHolder) holder);
        }
    }

    private void handlePhoneShopClick(Player player, int slot) {
        UUID uuid = player.getUniqueId();
        LanguageManager lang = plugin.getLanguageManager();

        if (slot == 26) {
            player.closeInventory();
            return;
        }

        if (slot != 11) return; // только обычный телефон продаётся сейчас

        double price = plugin.getConfig().getDouble("shop.phones.regular-phone.price", 5000);

        if (!plugin.getEconomyManager().has(player, price)) {
            player.sendMessage(ChatColor.RED + lang.get(uuid, "shop.insufficient-funds"));
            return;
        }

        plugin.getEconomyManager().withdraw(player, price);
        player.getInventory().addItem(PhoneItems.createPhoneItem(plugin));
        plugin.getPhoneManager().setBattery(uuid, 100);

        player.closeInventory();
        player.sendMessage(ChatColor.GREEN + lang.get(uuid, "shop.purchase-success") + " " + lang.get(uuid, "shop.regular-phone-name"));
    }

    private void handleTabacosClick(Player player, int slot, ShopGUI.TabacosShopHolder holder) {
        UUID uuid = player.getUniqueId();
        LanguageManager lang = plugin.getLanguageManager();

        if (slot == 26) {
            player.closeInventory();
            return;
        }

        int index = slot - 10;
        List<String> keys = holder.getKeysInOrder();
        if (index < 0 || index >= keys.size() || index >= 7) return;

        String key = keys.get(index);
        ConfigurationSection items = plugin.getConfig().getConfigurationSection("shop.tabacos.items");
        if (items == null) return;

        double price = items.getDouble(key + ".price", 0);
        String name = items.getString(key + ".name", key);
        String description = items.getString(key + ".description", "");

        if (!plugin.getEconomyManager().has(player, price)) {
            player.sendMessage(ChatColor.RED + lang.get(uuid, "shop.insufficient-funds"));
            return;
        }

        plugin.getEconomyManager().withdraw(player, price);

        for (String raw : items.getStringList(key + ".effects")) {
            PotionEffect effect = EffectUtil.parse(raw);
            if (effect != null) player.addPotionEffect(effect);
        }

        player.closeInventory();
        player.sendMessage(ChatColor.GREEN + lang.get(uuid, "shop.purchase-success") + " " + ChatColor.translateAlternateColorCodes('&', name));
        if (description != null && !description.isEmpty()) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', description));
        }
    }
}
