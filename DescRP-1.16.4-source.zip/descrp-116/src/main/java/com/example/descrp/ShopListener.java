package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.potion.PotionEffect;

import java.util.List;
import java.util.UUID;

public class ShopListener implements Listener {

    private final DescRP plugin;

    public ShopListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        Object holder = event.getInventory().getHolder();

        if (holder instanceof ShopGUI.PhoneShopHolder) {
            event.setCancelled(true);
            handlePhoneShopClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof ShopGUI.TabacosShopHolder) {
            event.setCancelled(true);
            handleTabacosClick(player, event.getRawSlot(), (ShopGUI.TabacosShopHolder) holder);
            return;
        }

        if (holder instanceof PhoneGUI.PaymentChoiceHolder) {
            event.setCancelled(true);
            handlePaymentChoiceClick(player, event.getRawSlot(), (PhoneGUI.PaymentChoiceHolder) holder);
            return;
        }

        if (holder instanceof PhoneGUI.BrowserHolder) {
            event.setCancelled(true);
            handleBrowserClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.BankHolder) {
            event.setCancelled(true);
            handleBankClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.NovaPoshtaHolder) {
            event.setCancelled(true);
            int size = event.getInventory().getSize();
            if (event.getRawSlot() == size - 1) {
                PhoneGUI.openMain(plugin, player);
            }
        }
    }

    // ===== Магазин телефонов =====

    private void handlePhoneShopClick(Player player, int slot) {
        UUID uuid = player.getUniqueId();
        LanguageManager lang = plugin.getLanguageManager();

        if (slot == 26) {
            player.closeInventory();
            return;
        }
        if (slot != 11) return;

        double price = plugin.getConfig().getDouble("shop.phones.regular-phone.price", 5000);
        PhoneGUI.openPaymentChoice(plugin, player, PhoneGUI.PaymentChoiceHolder.PurchaseType.PHONE, null, price,
                lang.get(uuid, "shop.regular-phone-name"));
    }

    // ===== Tabacos =====

    private void handleTabacosClick(Player player, int slot, ShopGUI.TabacosShopHolder holder) {
        if (slot == 26) {
            player.closeInventory();
            return;
        }

        int index = slot - 10;
        List<String> keys = holder.getKeysInOrder();
        if (index < 0 || index >= keys.size() || index >= 7) return;

        String key = keys.get(index);
        ConfigurationSection items = plugin.getConfig().getConfigurationSection("shop.tabacos.items");
        if (items == null) return;

        double price = items.getDouble(key + ".price", 0);
        String name = items.getString(key + ".name", key);

        PhoneGUI.openPaymentChoice(plugin, player, PhoneGUI.PaymentChoiceHolder.PurchaseType.TABACOS, key, price,
                ChatColor.translateAlternateColorCodes('&', name));
    }

    // ===== Выбор способа оплаты =====

    private void handlePaymentChoiceClick(Player player, int slot, PhoneGUI.PaymentChoiceHolder holder) {
        UUID uuid = player.getUniqueId();
        LanguageManager lang = plugin.getLanguageManager();

        boolean cash = slot == 11;
        boolean card = slot == 15;
        if (!cash && !card) return;

        if (card && !plugin.getCardManager().hasDebitCard(uuid)) {
            player.sendMessage(ChatColor.RED + lang.get(uuid, "gui.no-debit-card"));
            return;
        }

        double price = holder.getPrice();
        if (!plugin.getEconomyManager().has(player, price)) {
            player.sendMessage(ChatColor.RED + lang.get(uuid, "shop.insufficient-funds"));
            return;
        }
        plugin.getEconomyManager().withdraw(player, price);

        if (holder.getType() == PhoneGUI.PaymentChoiceHolder.PurchaseType.PHONE) {
            player.getInventory().addItem(PhoneItems.createPhoneItem(plugin));
            plugin.getPhoneManager().setBattery(uuid, 100);
            player.closeInventory();
            player.sendMessage(ChatColor.GREEN + lang.get(uuid, "shop.purchase-success") + " " + lang.get(uuid, "shop.regular-phone-name")
                    + " " + (card ? lang.get(uuid, "gui.paid-by-card") : lang.get(uuid, "gui.paid-by-cash")));
            return;
        }

        // TABACOS
        String key = holder.getTabacosKey();
        ConfigurationSection items = plugin.getConfig().getConfigurationSection("shop.tabacos.items");
        if (items == null) return;

        String name = items.getString(key + ".name", key);
        String description = items.getString(key + ".description", "");

        for (String raw : items.getStringList(key + ".effects")) {
            PotionEffect effect = EffectUtil.parse(raw);
            if (effect != null) player.addPotionEffect(effect);
        }

        player.closeInventory();
        player.sendMessage(ChatColor.GREEN + lang.get(uuid, "shop.purchase-success") + " " + ChatColor.translateAlternateColorCodes('&', name)
                + " " + (card ? lang.get(uuid, "gui.paid-by-card") : lang.get(uuid, "gui.paid-by-cash")));
        if (description != null && !description.isEmpty()) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', description));
        }
    }

    // ===== Браузер =====

    private void handleBrowserClick(Player player, int slot) {
        if (slot == 11) {
            if (!plugin.getEconomyManager().isEnabled()) {
                player.sendMessage(ChatColor.RED + "Магазин недоступен: не найден Vault с экономикой.");
                return;
            }
            ShopGUI.openPhoneShop(plugin, player);
        } else if (slot == 15) {
            if (!plugin.getEconomyManager().isEnabled()) {
                player.sendMessage(ChatColor.RED + "Магазин недоступен: не найден Vault с экономикой.");
                return;
            }
            ShopGUI.openTabacosShop(plugin, player);
        } else if (slot == 26) {
            PhoneGUI.openMain(plugin, player);
        }
    }

    // ===== Банк =====

    private void handleBankClick(Player player, int slot) {
        UUID uuid = player.getUniqueId();
        LanguageManager lang = plugin.getLanguageManager();

        if (slot == 11) {
            if (!plugin.getCardManager().hasDebitCard(uuid)) {
                plugin.getCardManager().issueDebitCard(uuid);
                player.sendMessage(ChatColor.GREEN + lang.get(uuid, "gui.debit-card-issued"));
                PhoneGUI.openBank(plugin, player);
            }
            return;
        }

        if (slot == 26) {
            PhoneGUI.openMain(plugin, player);
        }
    }
}
