package com.example.descrp;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class DocumentManager {

    public enum DocType {
        PASSPORT,
        DRIVER_LICENSE,
        WORK_PERMIT
    }

    public static class DocumentData {
        public String id;
        public String firstName;
        public String lastName;
        public String issueDate;
    }

    private final DescRP plugin;
    private final File dataFile;
    private final Random random = new Random();

    // playerUUID -> (тип документа -> данные)
    private final Map<UUID, Map<DocType, DocumentData>> documents = new HashMap<>();

    public DocumentManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "documents.yml");
    }

    public void load() {
        documents.clear();
        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection playersSection = yml.getConfigurationSection("players");
        if (playersSection == null) return;

        for (String uuidStr : playersSection.getKeys(false)) {
            UUID uuid;
            try {
                uuid = UUID.fromString(uuidStr);
            } catch (IllegalArgumentException ex) {
                continue;
            }

            Map<DocType, DocumentData> map = new EnumMap<>(DocType.class);
            for (DocType type : DocType.values()) {
                ConfigurationSection docSection = playersSection.getConfigurationSection(uuidStr + "." + type.name());
                if (docSection == null) continue;

                DocumentData data = new DocumentData();
                data.id = docSection.getString("id");
                data.firstName = docSection.getString("firstName");
                data.lastName = docSection.getString("lastName");
                data.issueDate = docSection.getString("issueDate");
                map.put(type, data);
            }
            documents.put(uuid, map);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();

        for (Map.Entry<UUID, Map<DocType, DocumentData>> entry : documents.entrySet()) {
            String base = "players." + entry.getKey();
            for (Map.Entry<DocType, DocumentData> docEntry : entry.getValue().entrySet()) {
                String path = base + "." + docEntry.getKey().name();
                DocumentData d = docEntry.getValue();
                yml.set(path + ".id", d.id);
                yml.set(path + ".firstName", d.firstName);
                yml.set(path + ".lastName", d.lastName);
                yml.set(path + ".issueDate", d.issueDate);
            }
        }

        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить documents.yml: " + e.getMessage());
        }
    }

    public boolean hasDocument(UUID uuid, DocType type) {
        Map<DocType, DocumentData> map = documents.get(uuid);
        return map != null && map.containsKey(type);
    }

    public boolean hasPassport(UUID uuid) {
        return hasDocument(uuid, DocType.PASSPORT);
    }

    public DocumentData getDocument(UUID uuid, DocType type) {
        Map<DocType, DocumentData> map = documents.get(uuid);
        return map == null ? null : map.get(type);
    }

    public void issueDocument(UUID uuid, DocType type, String firstName, String lastName) {
        DocumentData data = new DocumentData();
        data.id = generateId();
        data.firstName = firstName;
        data.lastName = lastName;
        data.issueDate = new SimpleDateFormat("dd.MM.yyyy").format(new Date());

        documents.computeIfAbsent(uuid, k -> new EnumMap<>(DocType.class)).put(type, data);
        save();
    }

    public void revokeDocument(UUID uuid, DocType type) {
        Map<DocType, DocumentData> map = documents.get(uuid);
        if (map != null) {
            map.remove(type);
            save();
        }
    }

    private String generateId() {
        int value = 10000000 + random.nextInt(90000000);
        return String.valueOf(value);
    }
}
