package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class VeipCommand implements CommandExecutor {

    private final DescRP plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public VeipCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }

        Player player = (Player) sender;
        UUID uuid = player.getUniqueId();
        LanguageManager lang = plugin.getLanguageManager();

        if (!hookahNearby(player)) {
            player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.no-hookah-nearby"));
            return true;
        }

        long cooldownSeconds = plugin.getConfig().getLong("hookah.cooldown-seconds", 60);
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(uuid);
        if (last != null && now - last < cooldownSeconds * 1000L) {
            long remain = (cooldownSeconds * 1000L - (now - last)) / 1000L;
            player.sendMessage(ChatColor.RED + lang.get(uuid, "msg.hookah-cooldown") + " " + remain + "с.");
            return true;
        }
        cooldowns.put(uuid, now);

        for (String raw : plugin.getConfig().getStringList("hookah.effects")) {
            PotionEffect effect = EffectUtil.parse(raw);
            if (effect != null) player.addPotionEffect(effect);
        }

        player.sendMessage(ChatColor.LIGHT_PURPLE + lang.get(uuid, "msg.hookah-used"));
        String description = plugin.getConfig().getString("hookah.description", "");
        if (!description.isEmpty()) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', description));
        }
        return true;
    }

    /** Ищет зельеварку (кальян), стоящую на нужном блоке, в небольшом радиусе вокруг игрока. */
    private boolean hookahNearby(Player player) {
        Material base;
        try {
            base = Material.valueOf(plugin.getConfig().getString("hookah.material-base", "WHITE_WOOL"));
        } catch (IllegalArgumentException ex) {
            base = Material.WHITE_WOOL;
        }

        Location center = player.getLocation();
        int radius = 2;

        for (int x = -radius; x <= radius; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Block block = center.clone().add(x, y, z).getBlock();
                    if (block.getType() != Material.BREWING_STAND) continue;
                    if (block.getRelative(BlockFace.DOWN).getType() == base) return true;
                }
            }
        }
        return false;
    }
}
