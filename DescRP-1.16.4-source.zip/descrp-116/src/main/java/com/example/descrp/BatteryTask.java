package com.example.descrp;

import org.bukkit.entity.Player;

import java.util.UUID;

public class BatteryTask implements Runnable {

    private final DescRP plugin;

    public BatteryTask(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        int drain = plugin.getConfig().getInt("battery.drain-per-interval", 2);
        int charge = plugin.getConfig().getInt("battery.charge-per-interval", 10);

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();

            if (plugin.getChargingManager().isPlayerDocked(uuid)) {
                plugin.getPhoneManager().chargeBattery(uuid, charge);
                plugin.getChargingManager().refreshLabelForPlayer(plugin, uuid);
                continue;
            }

            if (PhoneItems.findPhone(plugin, player.getInventory()) != null) {
                plugin.getPhoneManager().drainBattery(uuid, drain);
            }
        }

        plugin.getPhoneManager().save();
    }
}
