package com.example.descrp;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class DescRP extends JavaPlugin {

    private static DescRP instance;
    private PhoneManager phoneManager;
    private DocumentManager documentManager;
    private LanguageManager languageManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveDefaultLangFiles();

        this.phoneManager = new PhoneManager(this);
        phoneManager.load();

        this.documentManager = new DocumentManager(this);
        documentManager.load();

        this.languageManager = new LanguageManager(this);

        getServer().getPluginManager().registerEvents(new PhoneGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneInteractListener(this), this);

        PluginCommand phoneCmd = getCommand("phone");
        if (phoneCmd != null) {
            phoneCmd.setExecutor(new PhoneCommand(this));
        }

        PluginCommand docCmd = getCommand("doc");
        if (docCmd != null) {
            docCmd.setExecutor(new DocCommand(this));
        }

        getLogger().info("DescRP включен! Телефоны сервера Descend готовы к работе.");
    }

    @Override
    public void onDisable() {
        if (phoneManager != null) phoneManager.save();
        if (documentManager != null) documentManager.save();
        getLogger().info("DescRP выключен, данные сохранены.");
    }

    public void reload() {
        reloadConfig();
        languageManager.reload();
    }

    private void saveDefaultLangFiles() {
        String[] langs = {"en.yml", "ru.yml", "ua.yml"};
        for (String lang : langs) {
            File file = new File(getDataFolder(), "lang/" + lang);
            if (!file.exists()) {
                saveResource("lang/" + lang, false);
            }
        }
    }

    public static DescRP getInstance() {
        return instance;
    }

    public PhoneManager getPhoneManager() {
        return phoneManager;
    }

    public DocumentManager getDocumentManager() {
        return documentManager;
    }

    public LanguageManager getLanguageManager() {
        return languageManager;
    }
}
