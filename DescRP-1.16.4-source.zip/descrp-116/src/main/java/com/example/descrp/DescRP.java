package com.example.descrp;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class DescRP extends JavaPlugin {

    private static DescRP instance;
    private PhoneManager phoneManager;
    private DocumentManager documentManager;
    private LanguageManager languageManager;
    private ChargingManager chargingManager;
    private int batteryTaskId = -1;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveDefaultLangFiles();

        this.phoneManager = new PhoneManager(this);
        phoneManager.load();

        this.documentManager = new DocumentManager(this);
        documentManager.load();

        this.chargingManager = new ChargingManager(this);
        chargingManager.load();

        this.languageManager = new LanguageManager(this);

        getServer().getPluginManager().registerEvents(new PhoneGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneInteractListener(this), this);
        getServer().getPluginManager().registerEvents(new ChargingStationListener(this), this);
        getServer().getPluginManager().registerEvents(new PhoneJoinListener(this), this);

        PluginCommand phoneCmd = getCommand("phone");
        if (phoneCmd != null) {
            phoneCmd.setExecutor(new PhoneCommand(this));
        }

        PluginCommand docCmd = getCommand("doc");
        if (docCmd != null) {
            docCmd.setExecutor(new DocCommand(this));
        }

        startBatteryTask();

        getLogger().info("DescRP включен! Телефоны сервера Descend готовы к работе.");
    }

    @Override
    public void onDisable() {
        stopBatteryTask();
        if (phoneManager != null) phoneManager.save();
        if (documentManager != null) documentManager.save();
        if (chargingManager != null) chargingManager.save();
        getLogger().info("DescRP выключен, данные сохранены.");
    }

    public void reload() {
        reloadConfig();
        languageManager.reload();
        stopBatteryTask();
        startBatteryTask();
    }

    private void startBatteryTask() {
        int intervalMinutes = getConfig().getInt("battery.interval-minutes", 5);
        long ticks = Math.max(20L, intervalMinutes * 60L * 20L);
        batteryTaskId = getServer().getScheduler().scheduleSyncRepeatingTask(this, new BatteryTask(this), ticks, ticks);
    }

    private void stopBatteryTask() {
        if (batteryTaskId != -1) {
            getServer().getScheduler().cancelTask(batteryTaskId);
            batteryTaskId = -1;
        }
    }

    private void saveDefaultLangFiles() {
        String[] langs = {"en.yml", "ru.yml", "ua.yml"};
        for (String lang : langs) {
            File file = new File(getDataFolder(), "lang/" + lang);
            if (!file.exists()) {
                saveResource("lang/" + lang, false);
            }
        }
    }

    public static DescRP getInstance() {
        return instance;
    }

    public PhoneManager getPhoneManager() {
        return phoneManager;
    }

    public DocumentManager getDocumentManager() {
        return documentManager;
    }

    public LanguageManager getLanguageManager() {
        return languageManager;
    }

    public ChargingManager getChargingManager() {
        return chargingManager;
    }
}
