package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PhoneJoinListener implements Listener {

    private final DescRP plugin;

    public PhoneJoinListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        DocumentManager.DocRequest request = plugin.getDocumentManager().getRequest(player.getUniqueId());
        if (request == null) return;

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.sendMessage(ChatColor.YELLOW + "У вас есть заявка на документ. Наберите " + ChatColor.WHITE + "/doc pending" + ChatColor.YELLOW + ", чтобы посмотреть.");
        }, 40L);
    }
}
