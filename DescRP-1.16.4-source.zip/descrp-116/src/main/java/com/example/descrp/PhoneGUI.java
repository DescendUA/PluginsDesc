package com.example.descrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PhoneGUI {

    // ===== Holders — используются, чтобы отличать инвентари DescRP от чужих =====

    public static class MainHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class SettingsHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class ContactsHolder implements InventoryHolder {
        private final List<String> numbersInOrder;
        public ContactsHolder(List<String> numbersInOrder) { this.numbersInOrder = numbersInOrder; }
        public List<String> getNumbersInOrder() { return numbersInOrder; }
        @Override public Inventory getInventory() { return null; }
    }

    public static class DiaHolder implements InventoryHolder {
        private final boolean hasPassport;
        public DiaHolder(boolean hasPassport) { this.hasPassport = hasPassport; }
        public boolean hasPassport() { return hasPassport; }
        @Override public Inventory getInventory() { return null; }
    }

    /** Экран подтверждения заявки на документ (лайм = принять, красный = отклонить). */
    public static class DocConfirmHolder implements InventoryHolder {
        private final DocumentManager.DocType type;
        public DocConfirmHolder(DocumentManager.DocType type) { this.type = type; }
        public DocumentManager.DocType getType() { return type; }
        @Override public Inventory getInventory() { return null; }
    }

    public static class BrowserHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class BankHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class NovaPoshtaHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    /** Выбор способа оплаты (наличные/карта) перед завершением покупки в магазине. */
    public static class PaymentChoiceHolder implements InventoryHolder {
        public enum PurchaseType { PHONE, TABACOS }
        private final PurchaseType type;
        private final String tabacosKey;
        private final double price;

        public PaymentChoiceHolder(PurchaseType type, String tabacosKey, double price) {
            this.type = type;
            this.tabacosKey = tabacosKey;
            this.price = price;
        }

        public PurchaseType getType() { return type; }
        public String getTabacosKey() { return tabacosKey; }
        public double getPrice() { return price; }
        @Override public Inventory getInventory() { return null; }
    }

    // ===== Билд предметов =====

    public static ItemStack item(Material material, String name, String... lore) {
        return item(material, 0, name, lore);
    }

    /** customModelData = 1 подключает кастомную текстуру из ресурспака (см. overrides в модели предмета) */
    public static ItemStack item(Material material, int customModelData, String name, String... lore) {
        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore.length > 0) {
            List<String> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(ChatColor.translateAlternateColorCodes('&', line));
            }
            meta.setLore(loreList);
        }
        if (customModelData > 0) {
            meta.setCustomModelData(customModelData);
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack glass() {
        ItemStack item = new ItemStack(Material.BLACK_STAINED_GLASS_PANE, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(" ");
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack contactSkull(UUID ownerUUID, String displayName, String number) {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD, 1);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        OfflinePlayer owner = Bukkit.getOfflinePlayer(ownerUUID);
        meta.setOwningPlayer(owner);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&b" + displayName));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Номер: " + ChatColor.WHITE + number);
        lore.add(ChatColor.YELLOW + "ЛКМ — написать сообщение");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    /** Иконка батареи: материал и цвет названия зависят от текущего заряда. */
    public static ItemStack batteryItem(DescRP plugin, UUID uuid) {
        int level = plugin.getPhoneManager().getBattery(uuid);
        Material material;
        String colorCode;
        if (level > 60) {
            material = Material.LIME_DYE;
            colorCode = "&a";
        } else if (level > 20) {
            material = Material.YELLOW_DYE;
            colorCode = "&e";
        } else {
            material = Material.GRAY_DYE;
            colorCode = "&c";
        }

        String name = plugin.getLanguageManager().get(uuid, "gui.battery") + ": " + colorCode + level + "%";
        if (plugin.getChargingManager().isPlayerDocked(uuid)) {
            return item(material, name, plugin.getLanguageManager().get(uuid, "gui.battery-charging"));
        }
        return item(material, name);
    }

    // ===== Главный экран (приложения) =====

    public static void openMain(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.main-title");
        Inventory inv = Bukkit.createInventory(new MainHolder(), 36, ChatColor.translateAlternateColorCodes('&', title));

        for (int i = 0; i < 36; i++) inv.setItem(i, glass());

        // строка статуса сверху
        inv.setItem(8, batteryItem(plugin, uuid));

        // приложения — позиции берутся из персональной раскладки игрока (можно двигать shift+кликом)
        Map<String, Integer> layout = plugin.getPhoneManager().getIconLayout(uuid);

        inv.setItem(layout.get("settings"), item(Material.COMPARATOR, 1,
                plugin.getLanguageManager().get(uuid, "gui.app-settings"),
                plugin.getLanguageManager().get(uuid, "gui.app-settings-lore")));

        inv.setItem(layout.get("sms"), item(Material.PAPER, 1,
                plugin.getLanguageManager().get(uuid, "gui.app-sms"),
                plugin.getLanguageManager().get(uuid, "gui.app-sms-lore")));

        inv.setItem(layout.get("dia"), item(Material.BOOK,
                plugin.getLanguageManager().get(uuid, "gui.app-dia"),
                plugin.getLanguageManager().get(uuid, "gui.app-dia-lore")));

        inv.setItem(layout.get("browser"), item(Material.COMPASS,
                plugin.getLanguageManager().get(uuid, "gui.app-browser"),
                plugin.getLanguageManager().get(uuid, "gui.app-browser-lore")));

        inv.setItem(layout.get("bank"), item(Material.GOLD_INGOT,
                plugin.getLanguageManager().get(uuid, "gui.app-bank"),
                plugin.getLanguageManager().get(uuid, "gui.app-bank-lore")));

        inv.setItem(layout.get("novaposhta"), item(Material.CHEST,
                plugin.getLanguageManager().get(uuid, "gui.app-novaposhta"),
                plugin.getLanguageManager().get(uuid, "gui.app-novaposhta-lore")));

        player.openInventory(inv);
    }

    // ===== Настройки =====

    public static void openSettings(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.settings-title");
        Inventory inv = Bukkit.createInventory(new SettingsHolder(), 36, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 36; i++) inv.setItem(i, glass());

        inv.setItem(4, batteryItem(plugin, uuid));

        String number = plugin.getPhoneManager().getOrCreateNumber(uuid);
        inv.setItem(19, item(Material.NAME_TAG,
                plugin.getLanguageManager().get(uuid, "gui.my-number"),
                "&f" + number));

        String currentLang = plugin.getPhoneManager().getLanguage(uuid);
        if (currentLang == null) currentLang = plugin.getLanguageManager().getDefaultLang();
        inv.setItem(21, item(Material.WRITABLE_BOOK,
                plugin.getLanguageManager().get(uuid, "gui.language"),
                "&f" + currentLang.toUpperCase(),
                plugin.getLanguageManager().get(uuid, "gui.click-to-switch")));

        boolean notif = plugin.getPhoneManager().isNotificationsEnabled(uuid);
        inv.setItem(23, item(notif ? Material.EMERALD : Material.REDSTONE,
                plugin.getLanguageManager().get(uuid, "gui.notifications"),
                notif ? plugin.getLanguageManager().get(uuid, "gui.enabled")
                        : plugin.getLanguageManager().get(uuid, "gui.disabled"),
                plugin.getLanguageManager().get(uuid, "gui.click-to-toggle")));

        int contactsCount = plugin.getPhoneManager().getContacts(uuid).size();
        inv.setItem(25, item(Material.BOOKSHELF,
                plugin.getLanguageManager().get(uuid, "gui.contacts-count"),
                "&f" + contactsCount));

        inv.setItem(28, item(Material.ANVIL,
                plugin.getLanguageManager().get(uuid, "gui.reset-icons"),
                plugin.getLanguageManager().get(uuid, "gui.reset-icons-lore")));

        inv.setItem(30, item(Material.PAPER,
                plugin.getLanguageManager().get(uuid, "gui.drag-hint"),
                plugin.getLanguageManager().get(uuid, "gui.drag-hint-lore1"),
                plugin.getLanguageManager().get(uuid, "gui.drag-hint-lore2")));

        inv.setItem(35, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== SMS / Контакты =====

    public static void openContacts(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        Map<String, String> contacts = plugin.getPhoneManager().getContacts(uuid);

        int itemRows = (int) Math.ceil(contacts.size() / 9.0);
        int rows = Math.max(2, itemRows + 1); // +1 ряд под кнопки "добавить"/"назад"
        int size = Math.min(54, rows * 9);

        List<String> order = new ArrayList<>(contacts.keySet());
        ContactsHolder holder = new ContactsHolder(order);
        String title = plugin.getLanguageManager().get(uuid, "gui.contacts-title");
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.translateAlternateColorCodes('&', title));

        int slot = 0;
        for (String number : order) {
            String name = contacts.get(number);
            UUID contactUUID = plugin.getPhoneManager().getOwnerByNumber(number);
            inv.setItem(slot, contactSkull(contactUUID, name, number));
            slot++;
            if (slot >= size - 9) break;
        }

        inv.setItem(size - 9, item(Material.EMERALD,
                plugin.getLanguageManager().get(uuid, "gui.add-contact"),
                plugin.getLanguageManager().get(uuid, "gui.add-contact-lore")));
        inv.setItem(size - 1, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== Dia — документы =====

    public static void openDia(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        DocumentManager docs = plugin.getDocumentManager();
        String title = plugin.getLanguageManager().get(uuid, "gui.dia-title");
        Inventory inv = Bukkit.createInventory(new DiaHolder(docs.hasPassport(uuid)), 36, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 36; i++) inv.setItem(i, glass());

        if (!docs.hasPassport(uuid)) {
            inv.setItem(16, item(Material.EMERALD,
                    plugin.getLanguageManager().get(uuid, "gui.register-passport"),
                    plugin.getLanguageManager().get(uuid, "gui.register-passport-lore")));
            inv.setItem(35, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));
            player.openInventory(inv);
            return;
        }

        DocumentManager.DocumentData passport = docs.getDocument(uuid, DocumentManager.DocType.PASSPORT);
        int age = plugin.getPhoneManager().getAge(uuid);

        ItemStack ownerHead = contactSkull(uuid,
                plugin.getLanguageManager().get(uuid, "gui.owner-info"),
                passport.firstName + " " + passport.lastName);
        ItemMeta ownerMeta = ownerHead.getItemMeta();
        List<String> ownerLore = new ArrayList<>();
        ownerLore.add(ChatColor.WHITE + passport.firstName + " " + passport.lastName);
        ownerLore.add(ChatColor.GRAY + "ID: " + ChatColor.WHITE + passport.id);
        ownerLore.add(ChatColor.GRAY + plugin.getLanguageManager().get(uuid, "gui.age") + ": " + ChatColor.WHITE + age);
        ownerMeta.setLore(ownerLore);
        ownerHead.setItemMeta(ownerMeta);
        inv.setItem(4, ownerHead);

        inv.setItem(19, documentItem(plugin, uuid, DocumentManager.DocType.PASSPORT,
                plugin.getLanguageManager().get(uuid, "gui.doc-passport")));
        inv.setItem(21, documentItem(plugin, uuid, DocumentManager.DocType.DRIVER_LICENSE,
                plugin.getLanguageManager().get(uuid, "gui.doc-license")));
        inv.setItem(23, documentItem(plugin, uuid, DocumentManager.DocType.WORK_PERMIT,
                plugin.getLanguageManager().get(uuid, "gui.doc-permit")));
        inv.setItem(25, documentItem(plugin, uuid, DocumentManager.DocType.MEDICAL_CARD,
                plugin.getLanguageManager().get(uuid, "gui.doc-medcard")));

        inv.setItem(35, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    private static ItemStack documentItem(DescRP plugin, UUID uuid, DocumentManager.DocType type, String name) {
        DocumentManager.DocumentData data = plugin.getDocumentManager().getDocument(uuid, type);
        if (data == null) {
            return item(Material.PAPER, name,
                    plugin.getLanguageManager().get(uuid, "gui.doc-not-issued"));
        }
        return item(Material.WRITTEN_BOOK, name,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-owner") + ": &f" + data.firstName + " " + data.lastName,
                "&7ID: &f" + data.id,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-date") + ": &f" + data.issueDate);
    }

    // ===== Подтверждение заявки на документ от админа =====

    public static void openDocConfirm(DescRP plugin, Player player, DocumentManager.DocType type, String firstName, String lastName, String issuerName) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.confirm-title");
        Inventory inv = Bukkit.createInventory(new DocConfirmHolder(type), 27, ChatColor.translateAlternateColorCodes('&', title));

        ItemStack lime = item(Material.LIME_STAINED_GLASS_PANE, plugin.getLanguageManager().get(uuid, "gui.confirm-accept"));
        ItemStack red = item(Material.RED_STAINED_GLASS_PANE, plugin.getLanguageManager().get(uuid, "gui.confirm-deny"));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int slot = row * 9 + col;
                if (col < 4) {
                    inv.setItem(slot, lime);
                } else if (col > 4) {
                    inv.setItem(slot, red);
                }
            }
        }

        String docLabel = docTypeLabel(plugin, uuid, type);
        ItemStack info = item(Material.WRITTEN_BOOK,
                "&e" + docLabel,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-owner") + ": &f" + firstName + " " + lastName,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.confirm-issuer") + ": &f" + issuerName,
                "&8" + plugin.getLanguageManager().get(uuid, "gui.confirm-hint"));
        inv.setItem(4, info);
        inv.setItem(13, info);
        inv.setItem(22, info);

        player.openInventory(inv);
    }

    public static String docTypeLabel(DescRP plugin, UUID uuid, DocumentManager.DocType type) {
        switch (type) {
            case PASSPORT: return plugin.getLanguageManager().get(uuid, "gui.doc-passport");
            case DRIVER_LICENSE: return plugin.getLanguageManager().get(uuid, "gui.doc-license");
            case WORK_PERMIT: return plugin.getLanguageManager().get(uuid, "gui.doc-permit");
            case MEDICAL_CARD: return plugin.getLanguageManager().get(uuid, "gui.doc-medcard");
            default: return type.name();
        }
    }

    // ===== Браузер =====

    public static void openBrowser(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.browser-title");
        Inventory inv = Bukkit.createInventory(new BrowserHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        inv.setItem(11, item(Material.IRON_INGOT, 1,
                plugin.getLanguageManager().get(uuid, "shop.regular-phone-name") + " &7(/shop)",
                plugin.getLanguageManager().get(uuid, "gui.browser-shop-lore")));

        inv.setItem(15, item(Material.POTION,
                "&dTabacos &7(/tabacos)",
                plugin.getLanguageManager().get(uuid, "gui.browser-tabacos-lore")));

        inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== Банк (карты) =====

    public static void openBank(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.bank-title");
        Inventory inv = Bukkit.createInventory(new BankHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        CardManager cards = plugin.getCardManager();
        if (cards.hasDebitCard(uuid)) {
            CardManager.CardData data = cards.getDebitCard(uuid);
            inv.setItem(11, item(Material.PAPER,
                    plugin.getLanguageManager().get(uuid, "gui.debit-card"),
                    "&7" + plugin.getLanguageManager().get(uuid, "gui.card-number") + ": &f" + data.number,
                    "&7" + plugin.getLanguageManager().get(uuid, "gui.card-issued") + ": &f" + data.issueDate));
        } else {
            inv.setItem(11, item(Material.EMERALD,
                    plugin.getLanguageManager().get(uuid, "gui.register-debit-card"),
                    plugin.getLanguageManager().get(uuid, "gui.click-to-buy")));
        }

        inv.setItem(15, item(Material.BARRIER,
                plugin.getLanguageManager().get(uuid, "gui.credit-card"),
                "&7" + plugin.getLanguageManager().get(uuid, "shop.coming-soon")));

        inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== Нова Пошта =====

    public static void openNovaPoshta(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        List<PostboxManager.Postbox> list = plugin.getPostboxManager().getAll();

        int itemRows = (int) Math.ceil(list.size() / 9.0);
        int rows = Math.max(2, itemRows + 1);
        int size = Math.min(54, rows * 9);

        String title = plugin.getLanguageManager().get(uuid, "gui.novaposhta-title");
        Inventory inv = Bukkit.createInventory(new NovaPoshtaHolder(), size, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < size; i++) inv.setItem(i, glass());

        int slot = 0;
        for (PostboxManager.Postbox box : list) {
            if (slot >= size - 9) break;
            inv.setItem(slot, item(Material.CHEST,
                    "&e" + box.address,
                    "&7" + box.world + " " + box.x + ", " + box.y + ", " + box.z));
            slot++;
        }

        if (list.isEmpty()) {
            inv.setItem(size - 9, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.no-postboxes")));
        }

        inv.setItem(size - 1, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== Выбор способа оплаты =====

    public static void openPaymentChoice(DescRP plugin, Player player, PaymentChoiceHolder.PurchaseType type, String tabacosKey, double price, String itemName) {
        UUID uuid = player.getUniqueId();
        PaymentChoiceHolder holder = new PaymentChoiceHolder(type, tabacosKey, price);
        String title = plugin.getLanguageManager().get(uuid, "gui.payment-title");
        Inventory inv = Bukkit.createInventory(holder, 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        ItemStack info = item(Material.PAPER,
                "&e" + itemName,
                "&7" + plugin.getLanguageManager().get(uuid, "shop.price") + ": &f" + plugin.getEconomyManager().format(price));
        inv.setItem(4, info);
        inv.setItem(13, info);
        inv.setItem(22, info);

        inv.setItem(11, item(Material.EMERALD_BLOCK,
                plugin.getLanguageManager().get(uuid, "gui.pay-cash"),
                plugin.getLanguageManager().get(uuid, "gui.click-to-buy")));

        boolean hasCard = plugin.getCardManager().hasDebitCard(uuid);
        inv.setItem(15, item(hasCard ? Material.IRON_BLOCK : Material.BARRIER,
                plugin.getLanguageManager().get(uuid, "gui.pay-card"),
                hasCard ? plugin.getLanguageManager().get(uuid, "gui.click-to-buy")
                        : plugin.getLanguageManager().get(uuid, "gui.no-debit-card")));

        player.openInventory(inv);
    }
}
