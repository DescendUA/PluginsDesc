package com.example.descrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PhoneGUI {

    // ===== Holders — используются, чтобы отличать инвентари DescRP от чужих =====

    public static class MainHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class SettingsHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    public static class ContactsHolder implements InventoryHolder {
        private final List<String> numbersInOrder;
        public ContactsHolder(List<String> numbersInOrder) { this.numbersInOrder = numbersInOrder; }
        public List<String> getNumbersInOrder() { return numbersInOrder; }
        @Override public Inventory getInventory() { return null; }
    }

    public static class DiaHolder implements InventoryHolder {
        private final boolean hasPassport;
        public DiaHolder(boolean hasPassport) { this.hasPassport = hasPassport; }
        public boolean hasPassport() { return hasPassport; }
        @Override public Inventory getInventory() { return null; }
    }

    // ===== Билд предметов =====

    public static ItemStack item(Material material, String name, String... lore) {
        return item(material, 0, name, lore);
    }

    /** customModelData = 1 подключает кастомную текстуру из ресурспака (см. overrides в модели предмета) */
    public static ItemStack item(Material material, int customModelData, String name, String... lore) {
        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore.length > 0) {
            List<String> loreList = new ArrayList<>();
            for (String line : lore) {
                loreList.add(ChatColor.translateAlternateColorCodes('&', line));
            }
            meta.setLore(loreList);
        }
        if (customModelData > 0) {
            meta.setCustomModelData(customModelData);
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack glass() {
        ItemStack item = new ItemStack(Material.BLACK_STAINED_GLASS_PANE, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(" ");
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack contactSkull(UUID ownerUUID, String displayName, String number) {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD, 1);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        OfflinePlayer owner = Bukkit.getOfflinePlayer(ownerUUID);
        meta.setOwningPlayer(owner);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&b" + displayName));
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Номер: " + ChatColor.WHITE + number);
        lore.add(ChatColor.YELLOW + "ЛКМ — написать сообщение");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    // ===== Главный экран (приложения) =====

    public static void openMain(DescRP plugin, Player player) {
        String title = plugin.getLanguageManager().get(player.getUniqueId(), "gui.main-title");
        Inventory inv = Bukkit.createInventory(new MainHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));

        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        inv.setItem(11, item(Material.COMPARATOR, 1,
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-settings"),
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-settings-lore")));

        inv.setItem(13, item(Material.PAPER, 1,
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-sms"),
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-sms-lore")));

        inv.setItem(15, item(Material.BOOK,
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-dia"),
                plugin.getLanguageManager().get(player.getUniqueId(), "gui.app-dia-lore")));

        player.openInventory(inv);
    }

    // ===== Настройки =====

    public static void openSettings(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        String title = plugin.getLanguageManager().get(uuid, "gui.settings-title");
        Inventory inv = Bukkit.createInventory(new SettingsHolder(), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        String number = plugin.getPhoneManager().getOrCreateNumber(uuid);
        inv.setItem(10, item(Material.NAME_TAG,
                plugin.getLanguageManager().get(uuid, "gui.my-number"),
                "&f" + number));

        String currentLang = plugin.getPhoneManager().getLanguage(uuid);
        if (currentLang == null) currentLang = plugin.getLanguageManager().getDefaultLang();
        inv.setItem(12, item(Material.WRITABLE_BOOK,
                plugin.getLanguageManager().get(uuid, "gui.language"),
                "&f" + currentLang.toUpperCase(),
                plugin.getLanguageManager().get(uuid, "gui.click-to-switch")));

        boolean notif = plugin.getPhoneManager().isNotificationsEnabled(uuid);
        inv.setItem(14, item(notif ? Material.EMERALD : Material.REDSTONE,
                plugin.getLanguageManager().get(uuid, "gui.notifications"),
                notif ? plugin.getLanguageManager().get(uuid, "gui.enabled")
                        : plugin.getLanguageManager().get(uuid, "gui.disabled"),
                plugin.getLanguageManager().get(uuid, "gui.click-to-toggle")));

        int contactsCount = plugin.getPhoneManager().getContacts(uuid).size();
        inv.setItem(16, item(Material.BOOKSHELF,
                plugin.getLanguageManager().get(uuid, "gui.contacts-count"),
                "&f" + contactsCount));

        inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== SMS / Контакты =====

    public static void openContacts(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        Map<String, String> contacts = plugin.getPhoneManager().getContacts(uuid);

        int itemRows = (int) Math.ceil(contacts.size() / 9.0);
        int rows = Math.max(2, itemRows + 1); // +1 ряд под кнопки "добавить"/"назад"
        int size = Math.min(54, rows * 9);

        List<String> order = new ArrayList<>(contacts.keySet());
        ContactsHolder holder = new ContactsHolder(order);
        String title = plugin.getLanguageManager().get(uuid, "gui.contacts-title");
        Inventory inv = Bukkit.createInventory(holder, size, ChatColor.translateAlternateColorCodes('&', title));

        int slot = 0;
        for (String number : order) {
            String name = contacts.get(number);
            UUID contactUUID = plugin.getPhoneManager().getOwnerByNumber(number);
            inv.setItem(slot, contactSkull(contactUUID, name, number));
            slot++;
            if (slot >= size - 9) break;
        }

        inv.setItem(size - 9, item(Material.EMERALD,
                plugin.getLanguageManager().get(uuid, "gui.add-contact"),
                plugin.getLanguageManager().get(uuid, "gui.add-contact-lore")));
        inv.setItem(size - 1, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    // ===== Dia — документы =====

    public static void openDia(DescRP plugin, Player player) {
        UUID uuid = player.getUniqueId();
        DocumentManager docs = plugin.getDocumentManager();
        String title = plugin.getLanguageManager().get(uuid, "gui.dia-title");
        Inventory inv = Bukkit.createInventory(new DiaHolder(docs.hasPassport(uuid)), 27, ChatColor.translateAlternateColorCodes('&', title));
        for (int i = 0; i < 27; i++) inv.setItem(i, glass());

        if (!docs.hasPassport(uuid)) {
            inv.setItem(13, item(Material.EMERALD,
                    plugin.getLanguageManager().get(uuid, "gui.register-passport"),
                    plugin.getLanguageManager().get(uuid, "gui.register-passport-lore")));
            inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));
            player.openInventory(inv);
            return;
        }

        DocumentManager.DocumentData passport = docs.getDocument(uuid, DocumentManager.DocType.PASSPORT);
        ItemStack ownerHead = contactSkull(uuid,
                plugin.getLanguageManager().get(uuid, "gui.owner-info"),
                passport.firstName + " " + passport.lastName);
        ItemMeta ownerMeta = ownerHead.getItemMeta();
        List<String> ownerLore = new ArrayList<>();
        ownerLore.add(ChatColor.WHITE + passport.firstName + " " + passport.lastName);
        ownerLore.add(ChatColor.GRAY + "ID: " + ChatColor.WHITE + passport.id);
        ownerMeta.setLore(ownerLore);
        ownerHead.setItemMeta(ownerMeta);
        inv.setItem(4, ownerHead);

        inv.setItem(11, documentItem(plugin, uuid, DocumentManager.DocType.PASSPORT,
                plugin.getLanguageManager().get(uuid, "gui.doc-passport")));
        inv.setItem(13, documentItem(plugin, uuid, DocumentManager.DocType.DRIVER_LICENSE,
                plugin.getLanguageManager().get(uuid, "gui.doc-license")));
        inv.setItem(15, documentItem(plugin, uuid, DocumentManager.DocType.WORK_PERMIT,
                plugin.getLanguageManager().get(uuid, "gui.doc-permit")));

        inv.setItem(26, item(Material.BARRIER, plugin.getLanguageManager().get(uuid, "gui.back")));

        player.openInventory(inv);
    }

    private static ItemStack documentItem(DescRP plugin, UUID uuid, DocumentManager.DocType type, String name) {
        DocumentManager.DocumentData data = plugin.getDocumentManager().getDocument(uuid, type);
        if (data == null) {
            return item(Material.PAPER, name,
                    plugin.getLanguageManager().get(uuid, "gui.doc-not-issued"));
        }
        return item(Material.WRITTEN_BOOK, name,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-owner") + ": &f" + data.firstName + " " + data.lastName,
                "&7ID: &f" + data.id,
                "&7" + plugin.getLanguageManager().get(uuid, "gui.doc-date") + ": &f" + data.issueDate);
    }
}
