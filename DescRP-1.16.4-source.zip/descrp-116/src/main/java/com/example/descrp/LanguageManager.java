package com.example.descrp;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LanguageManager {

    private final DescRP plugin;
    private final Map<String, YamlConfiguration> languages = new HashMap<>();
    private String defaultLang;

    public LanguageManager(DescRP plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        languages.clear();
        defaultLang = plugin.getConfig().getString("language", "ru");
        String[] langs = {"en", "ru", "ua"};
        for (String lang : langs) {
            File file = new File(plugin.getDataFolder(), "lang/" + lang + ".yml");
            if (file.exists()) {
                languages.put(lang, YamlConfiguration.loadConfiguration(file));
            }
        }
    }

    public void reload() {
        load();
    }

    public String getDefaultLang() {
        return defaultLang;
    }

    public boolean hasLanguage(String lang) {
        return languages.containsKey(lang);
    }

    /** Сообщение с учётом персонального языка игрока (если задан). */
    public String get(UUID uuid, String key) {
        String lang = plugin.getPhoneManager().getLanguage(uuid);
        if (lang == null || !hasLanguage(lang)) lang = defaultLang;
        return get(lang, key);
    }

    public String get(String lang, String key) {
        YamlConfiguration config = languages.getOrDefault(lang, languages.get(defaultLang));
        if (config == null) return "&c[нет языкового файла: " + lang + "]";
        String value = config.getString(key);
        if (value == null) return "&c[missing: " + key + "]";
        return value;
    }
}
