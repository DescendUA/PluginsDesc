package com.example.descrp;

import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class EffectUtil {

    /** Формат строки: "SLOW:200:1" -> тип:длительность(тики):амплификатор */
    public static PotionEffect parse(String raw) {
        try {
            String[] parts = raw.split(":");
            PotionEffectType type = PotionEffectType.getByName(parts[0].trim());
            int duration = Integer.parseInt(parts[1].trim());
            int amplifier = Integer.parseInt(parts[2].trim());
            if (type == null) return null;
            return new PotionEffect(type, duration, amplifier);
        } catch (Exception ex) {
            return null;
        }
    }
}
