package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class PhoneCommand implements CommandExecutor {

    private final DescRP plugin;

    public PhoneCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("descrp.admin")) {
                sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
                return true;
            }

            Player target;
            if (args.length >= 2) {
                target = plugin.getServer().getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Игрок не найден.");
                    return true;
                }
            } else if (sender instanceof Player) {
                target = (Player) sender;
            } else {
                sender.sendMessage(ChatColor.RED + "Укажите игрока: /phone give <ник>");
                return true;
            }

            target.getInventory().addItem(createPhoneItem());
            sender.sendMessage(ChatColor.GREEN + "Телефон выдан игроку " + target.getName() + ".");
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }

        PhoneGUI.openMain(plugin, (Player) sender);
        return true;
    }

    private ItemStack createPhoneItem() {
        String materialName = plugin.getConfig().getString("phone-item.material", "IRON_INGOT");
        String displayName = plugin.getConfig().getString("phone-item.name", "&b&lТелефон");

        Material material;
        try {
            material = Material.valueOf(materialName);
        } catch (IllegalArgumentException ex) {
            material = Material.IRON_INGOT;
        }

        ItemStack item = new ItemStack(material, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', displayName));
        meta.setCustomModelData(1); // подключает кастомную текстуру из ресурспака

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "ПКМ, чтобы открыть меню");
        meta.setLore(lore);

        item.setItemMeta(meta);
        return item;
    }
}
