package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PhoneCommand implements CommandExecutor {

    private final DescRP plugin;

    public PhoneCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("descrp.admin")) {
                sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
                return true;
            }

            Player target;
            if (args.length >= 2) {
                target = plugin.getServer().getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Игрок не найден.");
                    return true;
                }
            } else if (sender instanceof Player) {
                target = (Player) sender;
            } else {
                sender.sendMessage(ChatColor.RED + "Укажите игрока: /phone give <ник>");
                return true;
            }

            target.getInventory().addItem(PhoneItems.createPhoneItem(plugin));
            plugin.getPhoneManager().setBattery(target.getUniqueId(), 100);
            sender.sendMessage(ChatColor.GREEN + "Телефон выдан игроку " + target.getName() + ".");
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }

        Player player = (Player) sender;

        if (plugin.getPhoneManager().getBattery(player.getUniqueId()) <= 0) {
            player.sendMessage(ChatColor.RED + plugin.getLanguageManager().get(player.getUniqueId(), "msg.battery-dead"));
            return true;
        }

        PhoneGUI.openMain(plugin, player);
        return true;
    }
}
