package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PhoneGUIListener implements Listener {

    private final DescRP plugin;

    /** Слот, выбранный игроком для перестановки значка (режим shift+клик, shift+клик). */
    private final Map<UUID, Integer> selectedIconSlot = new HashMap<>();

    public PhoneGUIListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player) {
            selectedIconSlot.remove(event.getPlayer().getUniqueId());
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        Object holder = event.getInventory().getHolder();

        if (holder instanceof PhoneGUI.MainHolder) {
            event.setCancelled(true);
            handleMainClick(player, event.getRawSlot(), event.isShiftClick());
            return;
        }

        if (holder instanceof PhoneGUI.SettingsHolder) {
            event.setCancelled(true);
            handleSettingsClick(player, event.getRawSlot());
            return;
        }

        if (holder instanceof PhoneGUI.ContactsHolder) {
            event.setCancelled(true);
            handleContactsClick(player, event.getRawSlot(), (PhoneGUI.ContactsHolder) holder, event.getCurrentItem());
            return;
        }

        if (holder instanceof PhoneGUI.DiaHolder) {
            event.setCancelled(true);
            handleDiaClick(player, event.getRawSlot(), (PhoneGUI.DiaHolder) holder);
            return;
        }

        if (holder instanceof PhoneGUI.DocConfirmHolder) {
            event.setCancelled(true);
            handleDocConfirmClick(player, event.getRawSlot(), (PhoneGUI.DocConfirmHolder) holder);
        }
    }

    private void handleMainClick(Player player, int slot, boolean shift) {
        UUID uuid = player.getUniqueId();
        if (slot < 0 || slot >= 36) return;
        if (slot == 8) return; // батарея — не трогаем

        String appId = plugin.getPhoneManager().appAtSlot(uuid, slot);

        if (!shift) {
            // обычный клик — открыть приложение (если тут есть значок), и сбросить незавершённую перестановку
            selectedIconSlot.remove(uuid);
            if (appId != null) openApp(player, appId);
            return;
        }

        // режим перестановки: shift+клик выбирает значок, второй shift+клик — куда его переставить
        Integer selected = selectedIconSlot.get(uuid);
        if (selected == null) {
            if (appId == null) return; // на пустом/декоративном слоте перестановку не начать
            selectedIconSlot.put(uuid, slot);
            player.sendMessage(ChatColor.YELLOW + plugin.getLanguageManager().get(uuid, "msg.icon-selected"));
            return;
        }

        if (selected == slot) {
            selectedIconSlot.remove(uuid);
            player.sendMessage(ChatColor.GRAY + plugin.getLanguageManager().get(uuid, "msg.cancelled"));
            return;
        }

        String movingApp = plugin.getPhoneManager().appAtSlot(uuid, selected);
        if (movingApp == null) {
            selectedIconSlot.remove(uuid);
            return;
        }
        String targetApp = appId;

        plugin.getPhoneManager().setIconSlot(uuid, movingApp, slot);
        if (targetApp != null) {
            plugin.getPhoneManager().setIconSlot(uuid, targetApp, selected);
        }

        selectedIconSlot.remove(uuid);
        player.sendMessage(ChatColor.GREEN + plugin.getLanguageManager().get(uuid, "msg.icons-swapped"));
        PhoneGUI.openMain(plugin, player);
    }

    private void openApp(Player player, String appId) {
        switch (appId) {
            case "settings": PhoneGUI.openSettings(plugin, player); break;
            case "sms": PhoneGUI.openContacts(plugin, player); break;
            case "dia": PhoneGUI.openDia(plugin, player); break;
            case "browser": PhoneGUI.openBrowser(plugin, player); break;
            case "bank": PhoneGUI.openBank(plugin, player); break;
            case "novaposhta": PhoneGUI.openNovaPoshta(plugin, player); break;
            default: break;
        }
    }

    private void handleSettingsClick(Player player, int slot) {
        UUID uuid = player.getUniqueId();

        if (slot == 21) {
            String newLang = plugin.getPhoneManager().cycleLanguage(uuid);
            player.sendMessage(ChatColor.GREEN + plugin.getLanguageManager().get(uuid, "msg.language-switched") + " " + newLang.toUpperCase());
            PhoneGUI.openSettings(plugin, player);
            return;
        }

        if (slot == 23) {
            plugin.getPhoneManager().toggleNotifications(uuid);
            PhoneGUI.openSettings(plugin, player);
            return;
        }

        if (slot == 28) {
            plugin.getPhoneManager().resetIconLayout(uuid);
            player.sendMessage(ChatColor.GREEN + plugin.getLanguageManager().get(uuid, "msg.icons-reset"));
            PhoneGUI.openSettings(plugin, player);
            return;
        }

        if (slot == 35) {
            PhoneGUI.openMain(plugin, player);
        }
    }

    private void handleContactsClick(Player player, int slot, PhoneGUI.ContactsHolder holder, ItemStack clicked) {
        List<String> order = holder.getNumbersInOrder();
        int rows = Math.max(2, (int) Math.ceil(order.size() / 9.0) + 1);
        int size = Math.min(54, rows * 9);

        if (slot == size - 1) { // назад
            PhoneGUI.openMain(plugin, player);
            return;
        }

        if (slot == size - 9) { // добавить контакт
            player.closeInventory();
            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.ADD_CONTACT_NUMBER);
            plugin.getPhoneManager().setPending(player.getUniqueId(), action);
            player.sendMessage(ChatColor.YELLOW + plugin.getLanguageManager().get(player.getUniqueId(), "msg.enter-number-to-add"));
            return;
        }

        if (slot >= 0 && slot < order.size() && clicked != null && clicked.getItemMeta() instanceof SkullMeta) {
            String number = order.get(slot);
            UUID targetUUID = plugin.getPhoneManager().getOwnerByNumber(number);
            if (targetUUID == null) {
                player.sendMessage(ChatColor.RED + plugin.getLanguageManager().get(player.getUniqueId(), "msg.number-invalid"));
                return;
            }

            player.closeInventory();
            String contactName = plugin.getPhoneManager().getContacts(player.getUniqueId()).get(number);

            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.SEND_MESSAGE);
            action.targetUUID = targetUUID;
            plugin.getPhoneManager().setPending(player.getUniqueId(), action);

            player.sendMessage(ChatColor.YELLOW + plugin.getLanguageManager().get(player.getUniqueId(), "msg.enter-message-for") + " " + ChatColor.WHITE + contactName + ChatColor.YELLOW + ":");
        }
    }

    private void handleDiaClick(Player player, int slot, PhoneGUI.DiaHolder holder) {
        if (slot == 35) {
            PhoneGUI.openMain(plugin, player);
            return;
        }

        if (!holder.hasPassport() && slot == 16) {
            player.closeInventory();
            UUID uuid = player.getUniqueId();
            PhoneManager.PendingAction action = new PhoneManager.PendingAction(PhoneManager.PendingType.REGISTER_PASSPORT_FIRSTNAME);
            plugin.getPhoneManager().setPending(uuid, action);
            player.sendMessage(ChatColor.YELLOW + plugin.getLanguageManager().get(uuid, "msg.enter-firstname"));
        }
    }

    private void handleDocConfirmClick(Player player, int slot, PhoneGUI.DocConfirmHolder holder) {
        UUID uuid = player.getUniqueId();
        int col = slot % 9;

        DocumentManager.DocRequest request = plugin.getDocumentManager().getRequest(uuid);
        if (request == null) {
            player.closeInventory();
            return;
        }

        if (col < 4) { // лайм — принять
            plugin.getDocumentManager().issueDocument(uuid, request.type, request.firstName, request.lastName);
            plugin.getDocumentManager().clearRequest(uuid);
            player.closeInventory();
            player.sendMessage(ChatColor.GREEN + plugin.getLanguageManager().get(uuid, "msg.request-accepted") + " " + PhoneGUI.docTypeLabel(plugin, uuid, request.type));
            return;
        }

        if (col > 4) { // красный — отклонить
            plugin.getDocumentManager().clearRequest(uuid);
            player.closeInventory();
            player.sendMessage(ChatColor.RED + plugin.getLanguageManager().get(uuid, "msg.request-denied"));
        }
    }
}
