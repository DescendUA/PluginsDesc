package com.example.descrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ChargingManager {

    private final DescRP plugin;
    private final File dataFile;

    // locationKey -> UUID голограммы (ArmorStand) над станцией. Наличие записи = "это станция".
    private final Map<String, UUID> stationHolograms = new HashMap<>();
    // locationKey -> playerUUID (чей телефон сейчас там заряжается)
    private final Map<String, UUID> dockedByLocation = new HashMap<>();
    // playerUUID -> locationKey (обратный индекс)
    private final Map<UUID, String> dockedByPlayer = new HashMap<>();

    public ChargingManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "charging.yml");
    }

    public void load() {
        stationHolograms.clear();
        dockedByLocation.clear();
        dockedByPlayer.clear();
        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        if (yml.getConfigurationSection("stations") == null) return;

        for (String locKey : yml.getConfigurationSection("stations").getKeys(false)) {
            String hologramStr = yml.getString("stations." + locKey + ".hologram");
            String dockedStr = yml.getString("stations." + locKey + ".docked");
            try {
                if (hologramStr != null) stationHolograms.put(locKey, UUID.fromString(hologramStr));
                if (dockedStr != null) {
                    UUID uuid = UUID.fromString(dockedStr);
                    dockedByLocation.put(locKey, uuid);
                    dockedByPlayer.put(uuid, locKey);
                }
            } catch (Exception ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<String, UUID> entry : stationHolograms.entrySet()) {
            yml.set("stations." + entry.getKey() + ".hologram", entry.getValue().toString());
            UUID docked = dockedByLocation.get(entry.getKey());
            if (docked != null) {
                yml.set("stations." + entry.getKey() + ".docked", docked.toString());
            }
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить charging.yml: " + e.getMessage());
        }
    }

    public static String key(Location loc) {
        return loc.getWorld().getName() + ";" + loc.getBlockX() + ";" + loc.getBlockY() + ";" + loc.getBlockZ();
    }

    // ===== Регистрация станций =====

    public boolean isStation(Location loc) {
        return stationHolograms.containsKey(key(loc));
    }

    /** Создаёт станцию на блоке и вешает над ним табличку-голограмму. */
    public void createStation(Location blockLoc) {
        Location holoLoc = blockLoc.clone().add(0.5, 1.2, 0.5);
        ArmorStand stand = holoLoc.getWorld().spawn(holoLoc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setMarker(true);
            as.setGravity(false);
            as.setSmall(true);
            as.setBasePlate(false);
            as.setCustomNameVisible(true);
        });
        stationHolograms.put(key(blockLoc), stand.getUniqueId());
        updateLabel(blockLoc);
        save();
    }

    /** Удаляет станцию и её голограмму. Возвращает true, если станция была найдена. */
    public boolean removeStation(Location blockLoc) {
        String k = key(blockLoc);
        UUID hologramId = stationHolograms.remove(k);
        if (hologramId == null) return false;

        Entity hologram = Bukkit.getEntity(hologramId);
        if (hologram != null) hologram.remove();

        UUID docked = dockedByLocation.remove(k);
        if (docked != null) dockedByPlayer.remove(docked);

        save();
        return true;
    }

    /** Обновляет текст над станцией в зависимости от того, занята она или нет. */
    public void updateLabel(Location blockLoc) {
        String k = key(blockLoc);
        UUID hologramId = stationHolograms.get(k);
        if (hologramId == null) return;

        Entity entity = Bukkit.getEntity(hologramId);
        if (!(entity instanceof ArmorStand)) return;
        ArmorStand stand = (ArmorStand) entity;

        UUID docked = dockedByLocation.get(k);
        String label;
        if (docked == null) {
            label = ChatColor.translateAlternateColorCodes('&', "&b&lЗарядная станция\n&aСвободна");
        } else {
            int battery = plugin.getPhoneManager().getBattery(docked);
            String ownerName = Bukkit.getOfflinePlayer(docked).getName();
            label = ChatColor.translateAlternateColorCodes('&', "&b&lЗарядная станция\n&cЗанята &7(" + ownerName + ") &f" + battery + "%");
        }
        // ArmorStand custom name не поддерживает перенос строки — используем короткую однострочную версию
        stand.setCustomName(label.replace("\n", " "));
    }

    // ===== Докинг телефонов =====

    public UUID getDockedPlayer(Location loc) {
        return dockedByLocation.get(key(loc));
    }

    public boolean isPlayerDocked(UUID uuid) {
        return dockedByPlayer.containsKey(uuid);
    }

    public String getStationKeyForPlayer(UUID uuid) {
        return dockedByPlayer.get(uuid);
    }

    public void dock(Location loc, UUID uuid) {
        String k = key(loc);
        dockedByLocation.put(k, uuid);
        dockedByPlayer.put(uuid, k);
        updateLabel(loc);
        save();
    }

    public void undock(UUID uuid) {
        String k = dockedByPlayer.remove(uuid);
        if (k != null) {
            dockedByLocation.remove(k);
            save();
        }
    }

    /** Обновляет голограмму станции, на которой сейчас стоит телефон игрока (вызывается при подзарядке). */
    public void refreshLabelForPlayer(DescRP plugin, UUID uuid) {
        String k = dockedByPlayer.get(uuid);
        if (k == null) return;
        String[] parts = k.split(";");
        if (parts.length != 4) return;
        org.bukkit.World world = Bukkit.getWorld(parts[0]);
        if (world == null) return;
        Location loc = new Location(world, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]), Double.parseDouble(parts[3]));
        updateLabel(loc);
    }
}
