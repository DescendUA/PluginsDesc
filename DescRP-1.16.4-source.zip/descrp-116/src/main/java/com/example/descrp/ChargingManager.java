package com.example.descrp;

import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ChargingManager {

    private final DescRP plugin;
    private final File dataFile;

    // locationKey -> playerUUID (чей телефон сейчас там заряжается)
    private final Map<String, UUID> dockedByLocation = new HashMap<>();
    // playerUUID -> locationKey (обратный индекс для быстрого поиска)
    private final Map<UUID, String> dockedByPlayer = new HashMap<>();

    public ChargingManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "charging.yml");
    }

    public void load() {
        dockedByLocation.clear();
        dockedByPlayer.clear();
        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        if (yml.getConfigurationSection("stations") == null) return;

        for (String locKey : yml.getConfigurationSection("stations").getKeys(false)) {
            String uuidStr = yml.getString("stations." + locKey);
            try {
                UUID uuid = UUID.fromString(uuidStr);
                dockedByLocation.put(locKey, uuid);
                dockedByPlayer.put(uuid, locKey);
            } catch (Exception ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<String, UUID> entry : dockedByLocation.entrySet()) {
            yml.set("stations." + entry.getKey(), entry.getValue().toString());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить charging.yml: " + e.getMessage());
        }
    }

    public static String key(Location loc) {
        return loc.getWorld().getName() + ";" + loc.getBlockX() + ";" + loc.getBlockY() + ";" + loc.getBlockZ();
    }

    public UUID getDockedPlayer(Location loc) {
        return dockedByLocation.get(key(loc));
    }

    public boolean isPlayerDocked(UUID uuid) {
        return dockedByPlayer.containsKey(uuid);
    }

    public void dock(Location loc, UUID uuid) {
        String k = key(loc);
        dockedByLocation.put(k, uuid);
        dockedByPlayer.put(uuid, k);
        save();
    }

    public void undock(UUID uuid) {
        String k = dockedByPlayer.remove(uuid);
        if (k != null) {
            dockedByLocation.remove(k);
            save();
        }
    }
}
