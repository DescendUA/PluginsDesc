package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class PhoneItems {

    public static Material phoneMaterial(DescRP plugin) {
        String materialName = plugin.getConfig().getString("phone-item.material", "IRON_INGOT");
        try {
            return Material.valueOf(materialName);
        } catch (IllegalArgumentException ex) {
            return Material.IRON_INGOT;
        }
    }

    public static String phoneDisplayName(DescRP plugin) {
        return ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("phone-item.name", "&b&lТелефон"));
    }

    public static boolean isPhone(DescRP plugin, ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        if (item.getType() != phoneMaterial(plugin)) return false;
        if (!item.getItemMeta().hasDisplayName()) return false;
        return item.getItemMeta().getDisplayName().equals(phoneDisplayName(plugin));
    }

    public static ItemStack createPhoneItem(DescRP plugin) {
        ItemStack item = new ItemStack(phoneMaterial(plugin), 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(phoneDisplayName(plugin));
        meta.setCustomModelData(1); // подключает кастомную текстуру из ресурспака

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "ПКМ, чтобы открыть меню");
        meta.setLore(lore);

        item.setItemMeta(meta);
        return item;
    }

    /** Ищет первый предмет-телефон в инвентаре игрока (включая руки), возвращает null, если не найден. */
    public static ItemStack findPhone(DescRP plugin, PlayerInventory inventory) {
        for (ItemStack stack : inventory.getContents()) {
            if (isPhone(plugin, stack)) return stack;
        }
        return null;
    }
}
