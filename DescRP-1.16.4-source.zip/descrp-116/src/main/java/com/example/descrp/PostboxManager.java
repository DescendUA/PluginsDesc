package com.example.descrp;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PostboxManager {

    public static class Postbox {
        public String address;
        public String world;
        public int x, y, z;
    }

    private final DescRP plugin;
    private final File dataFile;
    private final List<Postbox> postboxes = new ArrayList<>();

    public PostboxManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "postboxes.yml");
    }

    public void load() {
        postboxes.clear();
        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection section = yml.getConfigurationSection("postboxes");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            Postbox box = new Postbox();
            box.address = section.getString(key + ".address");
            box.world = section.getString(key + ".world");
            box.x = section.getInt(key + ".x");
            box.y = section.getInt(key + ".y");
            box.z = section.getInt(key + ".z");
            postboxes.add(box);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        int i = 0;
        for (Postbox box : postboxes) {
            String base = "postboxes." + i;
            yml.set(base + ".address", box.address);
            yml.set(base + ".world", box.world);
            yml.set(base + ".x", box.x);
            yml.set(base + ".y", box.y);
            yml.set(base + ".z", box.z);
            i++;
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить postboxes.yml: " + e.getMessage());
        }
    }

    public void create(Location loc, String address) {
        Postbox box = new Postbox();
        box.address = address;
        box.world = loc.getWorld().getName();
        box.x = loc.getBlockX();
        box.y = loc.getBlockY();
        box.z = loc.getBlockZ();
        postboxes.add(box);
        save();
    }

    public boolean removeAt(Location loc) {
        for (int i = 0; i < postboxes.size(); i++) {
            Postbox box = postboxes.get(i);
            if (matches(box, loc)) {
                postboxes.remove(i);
                save();
                return true;
            }
        }
        return false;
    }

    private boolean matches(Postbox box, Location loc) {
        World world = loc.getWorld();
        return world != null && box.world.equals(world.getName())
                && box.x == loc.getBlockX() && box.y == loc.getBlockY() && box.z == loc.getBlockZ();
    }

    public List<Postbox> getAll() {
        return postboxes;
    }
}
