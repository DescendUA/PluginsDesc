package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DrpCommand implements CommandExecutor {

    private final DescRP plugin;

    public DrpCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String lbl = label.toLowerCase();

        if (lbl.equals("shop")) {
            return openShop(sender);
        }
        if (lbl.equals("tabacos")) {
            return openTabacos(sender);
        }

        // /drp ...
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help":
                sendHelp(sender);
                return true;

            case "reload":
                if (!sender.hasPermission("descrp.admin")) {
                    sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
                    return true;
                }
                plugin.reload();
                sender.sendMessage(ChatColor.GREEN + "Конфигурация DescRP перезагружена.");
                return true;

            case "shop":
                return openShop(sender);

            case "tabacos":
                return openTabacos(sender);

            case "station":
                return handleStation(sender, args);

            case "postbox":
                return handlePostbox(sender, args);

            default:
                sendHelp(sender);
                return true;
        }
    }

    private boolean handleStation(CommandSender sender, String[] args) {
        if (!sender.hasPermission("descrp.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }
        Player player = (Player) sender;

        if (args.length < 2 || (!args[1].equalsIgnoreCase("create") && !args[1].equalsIgnoreCase("remove"))) {
            sender.sendMessage(ChatColor.RED + "Использование: /drp station <create|remove>");
            return true;
        }

        org.bukkit.block.Block target = player.getTargetBlockExact(6);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Посмотрите на блок станции (в пределах 6 блоков).");
            return true;
        }

        String materialName = plugin.getConfig().getString("charging-station.material", "BONE_BLOCK");
        if (!target.getType().name().equals(materialName)) {
            sender.sendMessage(ChatColor.RED + "Это должен быть блок: " + materialName + ".");
            return true;
        }

        ChargingManager charging = plugin.getChargingManager();

        if (args[1].equalsIgnoreCase("create")) {
            if (charging.isStation(target.getLocation())) {
                sender.sendMessage(ChatColor.RED + "Этот блок уже зарядная станция.");
                return true;
            }
            charging.createStation(target.getLocation());
            sender.sendMessage(ChatColor.GREEN + "Зарядная станция создана!");
        } else {
            if (charging.removeStation(target.getLocation())) {
                sender.sendMessage(ChatColor.GREEN + "Зарядная станция удалена.");
            } else {
                sender.sendMessage(ChatColor.RED + "Этот блок не является зарядной станцией.");
            }
        }
        return true;
    }

    private boolean handlePostbox(CommandSender sender, String[] args) {
        if (!sender.hasPermission("descrp.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }
        Player player = (Player) sender;

        if (args.length < 2 || (!args[1].equalsIgnoreCase("create") && !args[1].equalsIgnoreCase("remove"))) {
            sender.sendMessage(ChatColor.RED + "Использование: /drp postbox create <адрес> | /drp postbox remove");
            return true;
        }

        org.bukkit.block.Block target = player.getTargetBlockExact(6);
        if (target == null || target.getType() != org.bukkit.Material.CHEST) {
            sender.sendMessage(ChatColor.RED + "Посмотрите на сундук (в пределах 6 блоков) — он станет почтовым ящиком.");
            return true;
        }

        if (args[1].equalsIgnoreCase("create")) {
            if (args.length < 3) {
                sender.sendMessage(ChatColor.RED + "Использование: /drp postbox create <адрес>");
                return true;
            }
            String address = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
            plugin.getPostboxManager().create(target.getLocation(), address);
            sender.sendMessage(ChatColor.GREEN + "Почтовый ящик создан: " + address);
        } else {
            if (plugin.getPostboxManager().removeAt(target.getLocation())) {
                sender.sendMessage(ChatColor.GREEN + "Почтовый ящик удалён.");
            } else {
                sender.sendMessage(ChatColor.RED + "Этот сундук не является почтовым ящиком.");
            }
        }
        return true;
    }

    private boolean openShop(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }
        if (!plugin.getEconomyManager().isEnabled()) {
            sender.sendMessage(ChatColor.RED + "Магазин недоступен: не найден Vault с экономикой.");
            return true;
        }
        ShopGUI.openPhoneShop(plugin, (Player) sender);
        return true;
    }

    private boolean openTabacos(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }
        if (!plugin.getEconomyManager().isEnabled()) {
            sender.sendMessage(ChatColor.RED + "Магазин недоступен: не найден Vault с экономикой.");
            return true;
        }
        ShopGUI.openTabacosShop(plugin, (Player) sender);
        return true;
    }

    private void line(CommandSender sender, String s) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', s));
    }

    private void sendHelp(CommandSender sender) {
        line(sender, "&8&m----------------------------------------");
        line(sender, "&b&lDescRP &7» &fСписок команд");
        line(sender, "&f/drp help &7— это сообщение");
        line(sender, "&f/drp reload &7— перезагрузить конфиги");
        line(sender, "&f/phone &7— открыть телефон");
        line(sender, "&f/shop &7— магазин телефонов");
        line(sender, "&f/tabacos &7— магазин Tabacos");
        line(sender, "&f/veip &7— воспользоваться кальяном рядом");
        line(sender, "&f/doc pending &7— открыть заявку на документ");
        if (sender.hasPermission("descrp.admin")) {
            line(sender, "&7— &fАдмин:");
            line(sender, "&f/drp station create|remove &7— (смотря на блок) сделать/убрать зарядную станцию");
            line(sender, "&f/drp postbox create <адрес>|remove &7— (смотря на сундук) сделать/убрать почтовый ящик Новой Пошты");
        }
        line(sender, "&8&m----------------------------------------");
    }
}
