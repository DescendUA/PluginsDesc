package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DrpCommand implements CommandExecutor {

    private final DescRP plugin;

    public DrpCommand(DescRP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String lbl = label.toLowerCase();

        if (lbl.equals("shop")) {
            return openShop(sender);
        }
        if (lbl.equals("tabacos")) {
            return openTabacos(sender);
        }

        // /drp ...
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help":
                sendHelp(sender);
                return true;

            case "reload":
                if (!sender.hasPermission("descrp.admin")) {
                    sender.sendMessage(ChatColor.RED + "У вас нет прав на эту команду.");
                    return true;
                }
                plugin.reload();
                sender.sendMessage(ChatColor.GREEN + "Конфигурация DescRP перезагружена.");
                return true;

            case "shop":
                return openShop(sender);

            case "tabacos":
                return openTabacos(sender);

            default:
                sendHelp(sender);
                return true;
        }
    }

    private boolean openShop(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }
        if (!plugin.getEconomyManager().isEnabled()) {
            sender.sendMessage(ChatColor.RED + "Магазин недоступен: не найден Vault с экономикой.");
            return true;
        }
        ShopGUI.openPhoneShop(plugin, (Player) sender);
        return true;
    }

    private boolean openTabacos(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду может использовать только игрок.");
            return true;
        }
        if (!plugin.getEconomyManager().isEnabled()) {
            sender.sendMessage(ChatColor.RED + "Магазин недоступен: не найден Vault с экономикой.");
            return true;
        }
        ShopGUI.openTabacosShop(plugin, (Player) sender);
        return true;
    }

    private void line(CommandSender sender, String s) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', s));
    }

    private void sendHelp(CommandSender sender) {
        line(sender, "&8&m----------------------------------------");
        line(sender, "&b&lDescRP &7» &fСписок команд");
        line(sender, "&f/drp help &7— это сообщение");
        line(sender, "&f/drp reload &7— перезагрузить конфиги");
        line(sender, "&f/phone &7— открыть телефон");
        line(sender, "&f/shop &7— магазин телефонов");
        line(sender, "&f/tabacos &7— магазин Tabacos");
        line(sender, "&f/veip &7— воспользоваться кальяном рядом");
        line(sender, "&f/doc pending &7— открыть заявку на документ");
        line(sender, "&8&m----------------------------------------");
    }
}
