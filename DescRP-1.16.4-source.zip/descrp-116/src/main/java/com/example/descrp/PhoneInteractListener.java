package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class PhoneInteractListener implements Listener {

    private final DescRP plugin;

    public PhoneInteractListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (!isPhone(item)) return;

        Player player = event.getPlayer();
        event.setCancelled(true);
        PhoneGUI.openMain(plugin, player);
    }

    public boolean isPhone(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;

        String materialName = plugin.getConfig().getString("phone-item.material", "IRON_INGOT");
        String displayName = plugin.getConfig().getString("phone-item.name", "&b&lТелефон");

        Material material;
        try {
            material = Material.valueOf(materialName);
        } catch (IllegalArgumentException ex) {
            material = Material.IRON_INGOT;
        }

        if (item.getType() != material) return false;
        if (!item.getItemMeta().hasDisplayName()) return false;

        String expected = ChatColor.translateAlternateColorCodes('&', displayName);
        return item.getItemMeta().getDisplayName().equals(expected);
    }
}
