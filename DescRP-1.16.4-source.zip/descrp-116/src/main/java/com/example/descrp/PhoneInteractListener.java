package com.example.descrp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class PhoneInteractListener implements Listener {

    private final DescRP plugin;

    public PhoneInteractListener(DescRP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (!PhoneItems.isPhone(plugin, item)) return;

        Player player = event.getPlayer();
        event.setCancelled(true);

        if (plugin.getPhoneManager().getBattery(player.getUniqueId()) <= 0) {
            player.sendMessage(ChatColor.RED + plugin.getLanguageManager().get(player.getUniqueId(), "msg.battery-dead"));
            return;
        }

        PhoneGUI.openMain(plugin, player);
    }
}
