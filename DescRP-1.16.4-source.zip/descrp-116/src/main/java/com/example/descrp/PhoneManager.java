package com.example.descrp;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class PhoneManager {

    private final DescRP plugin;
    private final File dataFile;

    // playerUUID -> phone number
    private final Map<UUID, String> numbers = new HashMap<>();
    // phone number -> playerUUID
    private final Map<String, UUID> numberOwners = new HashMap<>();
    // playerUUID -> (contactNumber -> contactName)
    private final Map<UUID, Map<String, String>> contacts = new HashMap<>();

    // playerUUID -> персональный язык (en/ru/ua), может отсутствовать -> используется дефолтный
    private final Map<UUID, String> playerLanguage = new HashMap<>();

    // playerUUID -> включены ли уведомления о новых SMS (по умолчанию true)
    private final Map<UUID, Boolean> notificationsEnabled = new HashMap<>();

    // playerUUID -> возраст персонажа (по умолчанию 14)
    private final Map<UUID, Integer> age = new HashMap<>();

    // playerUUID -> заряд батареи телефона 0-100 (по умолчанию 100)
    private final Map<UUID, Integer> battery = new HashMap<>();

    // playerUUID -> (appId -> слот в главном меню). Отсутствующие приложения берут слот по умолчанию.
    private final Map<UUID, Map<String, Integer>> iconLayout = new HashMap<>();

    // Порядок и слоты приложений по умолчанию на главном экране (36 слотов, слот 8 занят батареей)
    public static final Map<String, Integer> DEFAULT_ICON_SLOTS = new LinkedHashMap<>();
    static {
        DEFAULT_ICON_SLOTS.put("settings", 10);
        DEFAULT_ICON_SLOTS.put("sms", 12);
        DEFAULT_ICON_SLOTS.put("dia", 14);
        DEFAULT_ICON_SLOTS.put("browser", 16);
        DEFAULT_ICON_SLOTS.put("bank", 19);
        DEFAULT_ICON_SLOTS.put("novaposhta", 21);
    }

    // in-memory pending chat actions (add contact / send message flow)
    private final Map<UUID, PendingAction> pending = new HashMap<>();

    private final Random random = new Random();

    public PhoneManager(DescRP plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        numbers.clear();
        numberOwners.clear();
        contacts.clear();
        playerLanguage.clear();
        notificationsEnabled.clear();
        age.clear();
        battery.clear();
        iconLayout.clear();

        if (!dataFile.exists()) return;

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection playersSection = yml.getConfigurationSection("players");
        if (playersSection == null) return;

        for (String uuidStr : playersSection.getKeys(false)) {
            UUID uuid;
            try {
                uuid = UUID.fromString(uuidStr);
            } catch (IllegalArgumentException ex) {
                continue;
            }

            String number = playersSection.getString(uuidStr + ".number");
            if (number != null) {
                numbers.put(uuid, number);
                numberOwners.put(number, uuid);
            }

            ConfigurationSection contactsSection = playersSection.getConfigurationSection(uuidStr + ".contacts");
            if (contactsSection != null) {
                Map<String, String> map = new LinkedHashMap<>();
                for (String contactNumber : contactsSection.getKeys(false)) {
                    map.put(contactNumber, contactsSection.getString(contactNumber));
                }
                contacts.put(uuid, map);
            }

            String lang = playersSection.getString(uuidStr + ".language");
            if (lang != null) playerLanguage.put(uuid, lang);

            if (playersSection.contains(uuidStr + ".notifications")) {
                notificationsEnabled.put(uuid, playersSection.getBoolean(uuidStr + ".notifications"));
            }

            if (playersSection.contains(uuidStr + ".age")) {
                age.put(uuid, playersSection.getInt(uuidStr + ".age"));
            }

            if (playersSection.contains(uuidStr + ".battery")) {
                battery.put(uuid, playersSection.getInt(uuidStr + ".battery"));
            }

            ConfigurationSection iconsSection = playersSection.getConfigurationSection(uuidStr + ".icons");
            if (iconsSection != null) {
                Map<String, Integer> map = new HashMap<>();
                for (String appId : iconsSection.getKeys(false)) {
                    map.put(appId, iconsSection.getInt(appId));
                }
                iconLayout.put(uuid, map);
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();

        for (Map.Entry<UUID, String> entry : numbers.entrySet()) {
            String path = "players." + entry.getKey() + ".number";
            yml.set(path, entry.getValue());
        }

        for (Map.Entry<UUID, Map<String, String>> entry : contacts.entrySet()) {
            String base = "players." + entry.getKey() + ".contacts";
            for (Map.Entry<String, String> c : entry.getValue().entrySet()) {
                yml.set(base + "." + c.getKey(), c.getValue());
            }
        }

        for (Map.Entry<UUID, String> entry : playerLanguage.entrySet()) {
            yml.set("players." + entry.getKey() + ".language", entry.getValue());
        }

        for (Map.Entry<UUID, Boolean> entry : notificationsEnabled.entrySet()) {
            yml.set("players." + entry.getKey() + ".notifications", entry.getValue());
        }

        for (Map.Entry<UUID, Integer> entry : age.entrySet()) {
            yml.set("players." + entry.getKey() + ".age", entry.getValue());
        }

        for (Map.Entry<UUID, Integer> entry : battery.entrySet()) {
            yml.set("players." + entry.getKey() + ".battery", entry.getValue());
        }

        for (Map.Entry<UUID, Map<String, Integer>> entry : iconLayout.entrySet()) {
            String base = "players." + entry.getKey() + ".icons";
            for (Map.Entry<String, Integer> icon : entry.getValue().entrySet()) {
                yml.set(base + "." + icon.getKey(), icon.getValue());
            }
        }

        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yml.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    public String getOrCreateNumber(UUID uuid) {
        String existing = numbers.get(uuid);
        if (existing != null) return existing;

        String generated;
        do {
            generated = generateNumber();
        } while (numberOwners.containsKey(generated));

        numbers.put(uuid, generated);
        numberOwners.put(generated, uuid);
        save();
        return generated;
    }

    private String generateNumber() {
        int value = 100000 + random.nextInt(900000);
        return String.valueOf(value);
    }

    public UUID getOwnerByNumber(String number) {
        return numberOwners.get(number);
    }

    public String getNumber(UUID uuid) {
        return numbers.get(uuid);
    }

    public Map<String, String> getContacts(UUID owner) {
        return contacts.computeIfAbsent(owner, k -> new LinkedHashMap<>());
    }

    public void addContact(UUID owner, String number, String name) {
        getContacts(owner).put(number, name);
        save();
    }

    public void removeContact(UUID owner, String number) {
        getContacts(owner).remove(number);
        save();
    }

    public String getLanguage(UUID uuid) {
        return playerLanguage.get(uuid);
    }

    /** Переключает язык игрока по кругу: ru -> en -> ua -> ru ... */
    public String cycleLanguage(UUID uuid) {
        String current = playerLanguage.getOrDefault(uuid, plugin.getConfig().getString("language", "ru"));
        String next;
        switch (current) {
            case "ru": next = "en"; break;
            case "en": next = "ua"; break;
            default: next = "ru"; break;
        }
        playerLanguage.put(uuid, next);
        save();
        return next;
    }

    public boolean isNotificationsEnabled(UUID uuid) {
        return notificationsEnabled.getOrDefault(uuid, true);
    }

    public boolean toggleNotifications(UUID uuid) {
        boolean newValue = !isNotificationsEnabled(uuid);
        notificationsEnabled.put(uuid, newValue);
        save();
        return newValue;
    }

    public int getAge(UUID uuid) {
        return age.getOrDefault(uuid, 14);
    }

    public void setAge(UUID uuid, int value) {
        age.put(uuid, value);
        save();
    }

    public int getBattery(UUID uuid) {
        return battery.getOrDefault(uuid, 100);
    }

    public void setBattery(UUID uuid, int value) {
        int clamped = Math.max(0, Math.min(100, value));
        battery.put(uuid, clamped);
    }

    /** Разряжает телефон на amount%, не сохраняет сразу (батарея сохраняется пачкой из BatteryTask). */
    public void drainBattery(UUID uuid, int amount) {
        setBattery(uuid, getBattery(uuid) - amount);
    }

    /** Заряжает телефон на amount%. */
    public void chargeBattery(UUID uuid, int amount) {
        setBattery(uuid, getBattery(uuid) + amount);
    }

    // ===== Раскладка значков главного экрана =====

    /** Текущая раскладка (appId -> слот) с учётом персональных перестановок игрока поверх дефолтной. */
    public Map<String, Integer> getIconLayout(UUID uuid) {
        Map<String, Integer> result = new LinkedHashMap<>(DEFAULT_ICON_SLOTS);
        Map<String, Integer> custom = iconLayout.get(uuid);
        if (custom != null) result.putAll(custom);
        return result;
    }

    /** Какое приложение сейчас находится в данном слоте (с учётом раскладки игрока), либо null. */
    public String appAtSlot(UUID uuid, int slot) {
        for (Map.Entry<String, Integer> entry : getIconLayout(uuid).entrySet()) {
            if (entry.getValue() == slot) return entry.getKey();
        }
        return null;
    }

    public void setIconSlot(UUID uuid, String appId, int slot) {
        iconLayout.computeIfAbsent(uuid, k -> new HashMap<>()).put(appId, slot);
        save();
    }

    public void resetIconLayout(UUID uuid) {
        iconLayout.remove(uuid);
        save();
    }

    public PendingAction getPending(UUID uuid) {
        return pending.get(uuid);
    }

    public void setPending(UUID uuid, PendingAction action) {
        if (action == null) {
            pending.remove(uuid);
        } else {
            pending.put(uuid, action);
        }
    }

    public enum PendingType {
        ADD_CONTACT_NUMBER,
        ADD_CONTACT_NAME,
        SEND_MESSAGE,
        REGISTER_PASSPORT_FIRSTNAME,
        REGISTER_PASSPORT_LASTNAME
    }

    public static class PendingAction {
        public final PendingType type;
        public String tempNumber;
        public String tempFirstName;
        public UUID targetUUID;

        public PendingAction(PendingType type) {
            this.type = type;
        }
    }
}
